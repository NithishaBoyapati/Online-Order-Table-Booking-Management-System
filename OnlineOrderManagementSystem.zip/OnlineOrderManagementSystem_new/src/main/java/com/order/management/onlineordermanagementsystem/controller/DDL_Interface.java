package com.order.management.onlineordermanagementsystem.controller;


import com.order.management.onlineordermanagementsystem.Model.Admin;
import com.order.management.onlineordermanagementsystem.Model.FoodItem;
import com.order.management.onlineordermanagementsystem.Model.FoodOrder;
import com.order.management.onlineordermanagementsystem.Model.Notification;
import com.order.management.onlineordermanagementsystem.Model.Customer;
import com.order.management.onlineordermanagementsystem.Model.Venue;

import java.util.ArrayList;

/**
 *
 * @author smacharla
 */
public interface DDL_Interface {

    public abstract ArrayList<Customer> selectAllOrderManagers();
    
    public abstract ArrayList<Notification> selectDistinctNotifications();

    public abstract ArrayList<Notification> selectAllNotifications();

    public abstract ArrayList<FoodOrder> selectAllFoodOrders();

    public abstract ArrayList<String> selectAllVenueTypes();

    public abstract ArrayList<String> selectAllOrderTypes();

    public abstract ArrayList<FoodItem> selectAllFoodItems();

    public abstract ArrayList<Venue> selectAllVenues();

    public abstract Customer selectOrderManagerDetails(int ID);

    public abstract Admin selectAdminPwd(String ID);

    public abstract ArrayList<String> selectGender();
}
