/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.order.management.onlineordermanagementsystem.View;

import com.order.management.onlineordermanagementsystem.Model.FoodItem;
import com.order.management.onlineordermanagementsystem.Model.FoodOrder;
import com.order.management.onlineordermanagementsystem.Model.Customer;
import com.order.management.onlineordermanagementsystem.Model.Venue;
import com.order.management.onlineordermanagementsystem.controller.DatabaseQueries;
import java.awt.Image;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import javax.swing.JOptionPane;
import javax.swing.JSpinner;
import javax.swing.SpinnerDateModel;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

/**
 *
 * @author smacharla
 */
public class BookOrderGUI extends javax.swing.JFrame {

    public BookOrderGUI() {
        initComponents();
    }

    public BookOrderGUI(Customer orderManager) {
        super("BookOrder");
        initComponents();
        setSize(755, 517);
        setResizable(false); // frame can't be resized
        setLocationRelativeTo(null); // set frame at center of screen
        setDefaultCloseOperation(EXIT_ON_CLOSE);  //default exist when prexx X icon

        this.orderManager = orderManager;

        //Set Welcome text
        //lblWelcome.setText("Welcome " + orderManager.getName());

        //Set Order Types
        ArrayList<String> orderTypeValues = DatabaseQueries.DDL().selectAllOrderTypes();
        cmbEventType.setModel(new DefaultComboBoxModel(orderTypeValues.toArray()));

        //Set Venue Types
        ArrayList<String> venueTypeValues = DatabaseQueries.DDL().selectAllVenueTypes();
        cmbVenueType.setModel(new DefaultComboBoxModel(venueTypeValues.toArray()));

        //Set Venue Names
        DefaultComboBoxModel<String> comboBoxModel = new DefaultComboBoxModel<String>();
        venues = DatabaseQueries.DDL().selectAllVenues();
        for (int i = 0; i < venues.size(); i++) {
            comboBoxModel.addElement(venues.get(i).getTableType());
        }
        cmbTableType.setModel(comboBoxModel);

        //Set Food Items
        DefaultListModel<String> foodItemListModel = new DefaultListModel<String>();
        foodItems = DatabaseQueries.DDL().selectAllFoodItems();
        for (int i = 0; i < foodItems.size(); i++) {
            foodItemListModel.addElement(foodItems.get(i).getFoodItemName());
        }
        listFoodItems.setModel(foodItemListModel);

        //Setting Venue Image to default Image
        setVenueImage();
        setGuestsCount();
        dateEvent.getJCalendar().setMinSelectableDate(new Date());

    }

    private void setVenueImage() {
        if (cmbTableType.getItemCount() > 0) {
            String tableType = cmbTableType.getSelectedItem().toString();
            String venuePath = "";
            for (int i = 0; i < venues.size(); i++) {
                if (venues.get(i).getTableType().equals(tableType)) {
                    venuePath = venues.get(i).getVenueImagePath();
                }
                if (!(venuePath != null && venuePath.trim().isEmpty())) {
                    lblVenueImage.setIcon(resizeImage(venuePath));
                } else {
                    lblVenueImage.setIcon(null);
                }
            }
        }
    }

    private ImageIcon resizeImage(String imagePath) {
        ImageIcon venueImage = new ImageIcon(imagePath);
        Image img = venueImage.getImage().getScaledInstance(lblVenueImage.getWidth(), lblVenueImage.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon venueFixedImage = new ImageIcon(img);
        return venueFixedImage;
    }

    private void setGuestsCount() {
        txtGuests.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                if (txtGuests.getText().trim().matches("\\d+")) {
                    setCosts();
                }
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                if (txtGuests.getText().trim().matches("\\d+")) {
                    setCosts();
                }
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                if (txtGuests.getText().trim().matches("\\d+")) {
                    setCosts();
                }
            }
        });
    }

    private void setCosts() {
        //Setting Venue Cost
        String tableType = cmbTableType.getSelectedItem().toString();
        double venueCost = 0;
        for (int i = 0; i < venues.size(); i++) {
            if (venues.get(i).getTableType().equals(tableType)) {
                venueCost = venues.get(i).getVenueCost();
                venue = venues.get(i);
            }
        }

        //Setting FoodItems Cost
        double foodItemsCost = 0;
        if (!listFoodItems.isSelectionEmpty()) {
            List<String> selectedFoodItems = listFoodItems.getSelectedValuesList();

            for (int i = 0; i < selectedFoodItems.size(); i++) {

                for (int j = 0; j < foodItems.size(); j++) {
                    if (foodItems.get(j).getFoodItemName().equals(selectedFoodItems.get(i))) {
                        foodItemsCost += foodItems.get(j).getFoodItemCost();
                    }
                }
            }
        }

        //Setting TotalCost
        String guests = txtGuests.getText().trim();
        int guestsCount = !guests.isEmpty() ? Integer.parseInt(guests) : 1;

        foodItemsCost = guestsCount * foodItemsCost;
        txtVenueCost.setText(venueCost + "$");
        txtFoodItemsCost.setText(foodItemsCost + "$");
        txtTotalCost.setText((venueCost + foodItemsCost) + "$");

    }

    @SuppressWarnings("unchecked")
                             
    private void initComponents() {

        jCalendar1 = new com.toedter.calendar.JCalendar();
        jMenu1 = new javax.swing.JMenu();
        bookOrderPanel = new javax.swing.JPanel();
        lblHeading = new javax.swing.JLabel();
        btnBack = new javax.swing.JButton();
        lblOrderType = new javax.swing.JLabel();
        FoodItemsScroll = new javax.swing.JScrollPane();
        listFoodItems = new javax.swing.JList<>();
        cmbEventType = new javax.swing.JComboBox<>();
        cmbTableType = new javax.swing.JComboBox<>();
        lblVenue = new javax.swing.JLabel();
        lblFoodItems = new javax.swing.JLabel();
        txtGuests = new javax.swing.JTextField();
        lblNoofGuests = new javax.swing.JLabel();
        lblVenueType = new javax.swing.JLabel();
        cmbVenueType = new javax.swing.JComboBox<>();
        lblBookingDate = new javax.swing.JLabel();
        lblBookingTime = new javax.swing.JLabel();
        btnBook = new javax.swing.JButton();
        txtVenueCost = new javax.swing.JTextField();
        lblVenueCost = new javax.swing.JLabel();
        txtFoodItemsCost = new javax.swing.JTextField();
        lblFoodItemsCost = new javax.swing.JLabel();
        txtTotalCost = new javax.swing.JTextField();
        lblTotalCost = new javax.swing.JLabel();
        lblVenueImage = new javax.swing.JLabel();
        dateEvent = new com.toedter.calendar.JDateChooser();
        lblWelcome = new javax.swing.JLabel();
        Background = new javax.swing.JLabel();
        cmbOrderTime = new javax.swing.JComboBox<>();

        jMenu1.setText("jMenu1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        bookOrderPanel.setBackground(new java.awt.Color(0, 0, 0));
        bookOrderPanel.setPreferredSize(new java.awt.Dimension(800, 572));
        bookOrderPanel.setLayout(null);

        lblHeading.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblHeading.setForeground(new java.awt.Color(255, 255, 255));
        lblHeading.setText("BOOK AN ORDER");
        bookOrderPanel.add(lblHeading);
        lblHeading.setBounds(321, 19, 110, 15);

        btnBack.setBackground(new java.awt.Color(0, 0, 0));
        btnBack.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnBack.setForeground(new java.awt.Color(255, 255, 255));
        btnBack.setText("BACK");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });
        bookOrderPanel.add(btnBack);
        
        btnBack.setBounds(480, 390, 98, 23);
        lblOrderType.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblOrderType.setForeground(new java.awt.Color(255, 255, 255));
        lblOrderType.setText("Order Type");
        bookOrderPanel.add(lblOrderType);
        lblOrderType.setBounds(32, 81, 80, 15);

        listFoodItems.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                listFoodItemsValueChanged(evt);
            }
        });
        FoodItemsScroll.setViewportView(listFoodItems);

        bookOrderPanel.add(FoodItemsScroll);
        FoodItemsScroll.setBounds(550, 80, 128, 59);

        bookOrderPanel.add(cmbEventType);
        cmbEventType.setBounds(170, 79, 128, 20);

        cmbTableType.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbTableTypeActionPerformed(evt);
            }
        });
        bookOrderPanel.add(cmbTableType);
        cmbTableType.setBounds(170, 117, 128, 20);

        lblVenue.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblVenue.setForeground(new java.awt.Color(255, 255, 255));
        lblVenue.setText("Table Type");
        bookOrderPanel.add(lblVenue);
        lblVenue.setBounds(32, 119, 80, 15);

        lblFoodItems.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblFoodItems.setForeground(new java.awt.Color(255, 255, 255));
        lblFoodItems.setText("Food Items");
        bookOrderPanel.add(lblFoodItems);
        lblFoodItems.setBounds(420, 100, 70, 15);

        bookOrderPanel.add(txtGuests);
        txtGuests.setBounds(550, 148, 128, 20);

        lblNoofGuests.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lblNoofGuests.setForeground(new java.awt.Color(255, 255, 255));
        lblNoofGuests.setText("No Of Guests");
        bookOrderPanel.add(lblNoofGuests);
        lblNoofGuests.setBounds(420, 148, 71, 14);

        lblVenueType.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblVenueType.setForeground(new java.awt.Color(255, 255, 255));
        lblVenueType.setText("Venue Type");
        bookOrderPanel.add(lblVenueType);
        lblVenueType.setBounds(32, 157, 80, 15);

        bookOrderPanel.add(cmbVenueType);
        cmbVenueType.setBounds(170, 155, 128, 20);

        lblBookingDate.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblBookingDate.setForeground(new java.awt.Color(255, 255, 255));
        lblBookingDate.setText("Order Date");
        bookOrderPanel.add(lblBookingDate);
        lblBookingDate.setBounds(32, 198, 80, 15);

        lblBookingTime.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblBookingTime.setForeground(new java.awt.Color(255, 255, 255));
        lblBookingTime.setText("Order Time");
        bookOrderPanel.add(lblBookingTime);
        lblBookingTime.setBounds(32, 233, 80, 15);

//        JSpinner timeSpinner = new JSpinner(new SpinnerDateModel());
//        JSpinner.DateEditor timeEditor = new JSpinner.DateEditor(timeSpinner, "HH:mm:ss");
//        timeSpinner.setEditor(timeEditor);
//        timeSpinner.setValue(new Date());
//        bookOrderPanel.add(timeSpinner);
        cmbOrderTime.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "","7:00 AM", "8:00 AM", "9:00 AM", "12:00 PM", "1:00 PM", "2:00 PM", "7:00 PM", "8:00 PM", "9:00 PM"}));
        bookOrderPanel.add(cmbOrderTime);
        cmbOrderTime.setBounds(170, 233, 128, 20);    
        ;  
        
        
        btnBook.setBackground(new java.awt.Color(0, 0, 0));
        btnBook.setForeground(new java.awt.Color(255, 255, 255));
        btnBook.setText("Book");
        btnBook.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBookActionPerformed(evt);
            }
        });
        bookOrderPanel.add(btnBook);
        btnBook.setBounds(480, 350, 98, 23);

        txtVenueCost.setEditable(false);
        txtVenueCost.setBackground(new java.awt.Color(255, 255, 255));
        bookOrderPanel.add(txtVenueCost);
        txtVenueCost.setBounds(550, 180, 130, 20);

        lblVenueCost.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblVenueCost.setForeground(new java.awt.Color(255, 255, 255));
        lblVenueCost.setText("Venue Cost");
        bookOrderPanel.add(lblVenueCost);
        lblVenueCost.setBounds(420, 180, 118, 15);

        txtFoodItemsCost.setEditable(false);
        txtFoodItemsCost.setBackground(new java.awt.Color(255, 255, 255));
        bookOrderPanel.add(txtFoodItemsCost);
        txtFoodItemsCost.setBounds(550, 210, 130, 20);

        lblFoodItemsCost.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblFoodItemsCost.setForeground(new java.awt.Color(255, 255, 255));
        lblFoodItemsCost.setText("Food Cost");
        bookOrderPanel.add(lblFoodItemsCost);
        lblFoodItemsCost.setBounds(420, 210, 112, 17);

        txtTotalCost.setEditable(false);
        txtTotalCost.setBackground(new java.awt.Color(255, 255, 255));
        bookOrderPanel.add(txtTotalCost);
        txtTotalCost.setBounds(550, 240, 130, 20);

        lblTotalCost.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblTotalCost.setForeground(new java.awt.Color(255, 255, 255));
        lblTotalCost.setText("Total Cost");
        bookOrderPanel.add(lblTotalCost);
        lblTotalCost.setBounds(420, 240, 78, 15);

        lblVenueImage.setForeground(new java.awt.Color(255, 255, 255));
        lblVenueImage.setOpaque(true);
        bookOrderPanel.add(lblVenueImage);
        lblVenueImage.setBounds(150, 260, 308, 206);
        //lblVenueImage.setBounds(420, 79, 308, 206);

        //dateEvent.setDateFormatString("YYYY-MM-dd");
        bookOrderPanel.add(dateEvent);
        dateEvent.setBounds(170, 193, 128, 20);



        lblWelcome.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblWelcome.setForeground(new java.awt.Color(255, 255, 255));
        lblWelcome.setText("Welcome");
        bookOrderPanel.add(lblWelcome);
        lblWelcome.setBounds(32, 19, 160, 15);


        bookOrderPanel.add(Background);
        Background.setBounds(0, 0, 760, 520);

        getContentPane().add(bookOrderPanel);
        bookOrderPanel.setBounds(0, 0, 755, 517);

        pack();
    }                        

    private void btnBookActionPerformed(java.awt.event.ActionEvent evt) {
        String orderType = cmbEventType.getSelectedItem().toString();
        String tableType = cmbTableType.getItemCount() > 0 ? cmbTableType.getSelectedItem().toString() : "";
        String venueType = cmbVenueType.getSelectedItem().toString();
        String orderTime = cmbOrderTime.getSelectedItem().toString();
        Date orderDate = new Date();
        orderDate = dateEvent.getDate();
        String guests = txtGuests.getText();
        String validationMessage = "";
        if (orderDate == null) {
            validationMessage += "Order Date is empty";
        }
//        if (orderTime == null) {
//            validationMessage += "Order Time is empty";
//        }
        if (tableType.trim().isEmpty()) {
            validationMessage += "\nVenue is empty";
        }
        if (listFoodItems.isSelectionEmpty()) {
            validationMessage += "\nFood Items List is empty";
        }
        if (guests.trim().isEmpty()) {
            validationMessage += "\nGuests Count is empty";
        }
        if (validationMessage != "") {
            JOptionPane.showMessageDialog(null, validationMessage); // show message
            return;
        }
        if (!guests.trim().matches("\\d+")) {
            JOptionPane.showMessageDialog(null, "No of Guests is invalid"); // show message
            return;
        }
        if (orderTime.equals("")){
            JOptionPane.showMessageDialog(null, "Select the order time"); // show message
            return;
        }

        String todaysDate = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date today;
        try {
            today = sdf.parse(todaysDate);
            if (orderDate.compareTo(today) < 0) {
                System.out.println("Order Date should be a future date");
            }
        } catch (ParseException ex) {
            Logger.getLogger(BookOrderGUI.class.getName()).log(Level.SEVERE, null, ex);
        }
        Double venueCost = Double.parseDouble(txtVenueCost.getText().replace("$", ""));
        Double foodItemsCost = Double.parseDouble(txtFoodItemsCost.getText().replace("$", ""));
        Double totalCost = Double.parseDouble(txtTotalCost.getText().replace("$", ""));

        String foodItems = String.join(",", listFoodItems.getSelectedValuesList());
         System.out.println("Custermer" + orderManager.getCustomerID());

        @SuppressWarnings("null")
        FoodOrder order = new FoodOrder(orderManager.getCustomerID(), orderType, tableType, venueType, new java.sql.Date(orderDate.getTime()), orderTime, foodItems, Integer.parseInt(guests), venueCost, foodItemsCost, totalCost, "Pending");

        order.setBookingID(DatabaseQueries.DML().InsertOrder(order));
        JOptionPane.showMessageDialog(this, "Order placed successfully. Your Booking ID is:" + order.getBookingID());

        //Open Payment page passing booking id ,venue image,total cost details
        OrderPaymentGUI paymentGUI = new OrderPaymentGUI(orderManager, venue, order);
        this.setVisible(false);
        paymentGUI.setVisible(true);
    }

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {

        this.setVisible(false);
        this.dispose();
        CustomerHomeGUI home = new CustomerHomeGUI(orderManager);
        home.setVisible(true);

    }

   // private void cmbVenueNameActionPerformed(java.awt.event.ActionEvent evt) {
        //Set Venue Image and Venue Cost when change in Venue
     //   setVenueImage();
       // setCosts();
    //}
    
    private void cmbTableTypeActionPerformed(java.awt.event.ActionEvent evt) {
        setVenueImage();
        setCosts();
    }

    private void listFoodItemsValueChanged(javax.swing.event.ListSelectionEvent evt) {
        if (!evt.getValueIsAdjusting()) {
            setCosts();
        }
    }

    Customer orderManager;
    Venue venue;
    ArrayList<Venue> venues = new ArrayList<Venue>();
    ArrayList<FoodItem> foodItems = new ArrayList<FoodItem>();

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new BookOrderGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify                     
    private javax.swing.JLabel Background;
    private javax.swing.JScrollPane FoodItemsScroll;
    private javax.swing.JPanel bookOrderPanel;
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnBook;
    private javax.swing.JComboBox<String> cmbEventType;
    private javax.swing.JComboBox<String> cmbTableType;
    private javax.swing.JComboBox<String> cmbVenueType;
    private com.toedter.calendar.JDateChooser dateEvent;
    private com.toedter.calendar.JCalendar jCalendar1;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JLabel lblBookingTime;
    private javax.swing.JLabel lblBookingDate;
    private javax.swing.JLabel lblOrderType;
    private javax.swing.JLabel lblFoodItems;
    private javax.swing.JLabel lblFoodItemsCost;
    private javax.swing.JLabel lblHeading;
    private javax.swing.JLabel lblNoofGuests;
    private javax.swing.JLabel lblTotalCost;
    private javax.swing.JLabel lblVenue;
    private javax.swing.JLabel lblVenueCost;
    private javax.swing.JLabel lblVenueImage;
    private javax.swing.JLabel lblVenueType;
    private javax.swing.JLabel lblWelcome;
    private javax.swing.JList<String> listFoodItems;
    private javax.swing.JTextField txtFoodItemsCost;
    private javax.swing.JTextField txtGuests;
    private javax.swing.JTextField txtTotalCost;
    private javax.swing.JTextField txtVenueCost;
    private javax.swing.JComboBox<String> cmbOrderTime;
    // End of variables declaration                   
}
