/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.order.management.onlineordermanagementsystem.View;

/**
 *
 * @author smacharla
 */
public class AdminHomePageGUI extends javax.swing.JFrame {

    public AdminHomePageGUI() {
        super("AdminHomePage");
        initComponents();
        setSize(740, 400);  //set size of frame
        setResizable(false); // frame can't be resized
        setLocationRelativeTo(null); // set frame at center of screen
        setDefaultCloseOperation(EXIT_ON_CLOSE);  //default exist when prexx X icon
    }

    @SuppressWarnings("unchecked")
                             
    private void initComponents() {

        adminHomePanel = new javax.swing.JPanel();
        lblWelcome = new javax.swing.JLabel();
        btnLogout = new javax.swing.JButton();
        btnVenueManagement = new javax.swing.JButton();
        btnFoodManagement = new javax.swing.JButton();
        btnEquipmentManagement = new javax.swing.JButton();
        btnViewBookings = new javax.swing.JButton();
        btnManageNotifications = new javax.swing.JButton();
        Background = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(36, 37, 130));

        adminHomePanel.setBackground(new java.awt.Color(0, 0, 0));
        adminHomePanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblWelcome.setBackground(new java.awt.Color(36, 37, 130));
        lblWelcome.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblWelcome.setForeground(new java.awt.Color(255, 255, 255));
        lblWelcome.setText("WELCOME ADMIN");
        adminHomePanel.add(lblWelcome, new org.netbeans.lib.awtextra.AbsoluteConstraints(18, 15, -1, -1));

        btnLogout.setBackground(new java.awt.Color(0, 0, 0));
        btnLogout.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnLogout.setForeground(new java.awt.Color(255, 255, 255));
        btnLogout.setText("LOGOUT");
        btnLogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLogoutActionPerformed(evt);
            }
        });
        adminHomePanel.add(btnLogout, new org.netbeans.lib.awtextra.AbsoluteConstraints(640, 10, -1, -1));

        btnVenueManagement.setBackground(new java.awt.Color(0, 0, 0));
        btnVenueManagement.setForeground(new java.awt.Color(255, 255, 255));
        btnVenueManagement.setText("MANAGE VENUE");
        btnVenueManagement.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVenueManagementActionPerformed(evt);
            }
        });
        
        adminHomePanel.add(btnVenueManagement, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 70, 300, 50));
        btnFoodManagement.setBackground(new java.awt.Color(0, 0, 0));
        btnFoodManagement.setForeground(new java.awt.Color(255, 255, 255));
        btnFoodManagement.setText("MANAGE FOOD");
        btnFoodManagement.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFoodManagementActionPerformed(evt);
            }
        });
        adminHomePanel.add(btnFoodManagement, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 140, 300, 50));
        btnViewBookings.setBackground(new java.awt.Color(0, 0, 0));
        btnViewBookings.setForeground(new java.awt.Color(255, 255, 255));
        btnViewBookings.setText("VIEW BOOKINGS");
        btnViewBookings.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnViewBookingsActionPerformed(evt);
            }
        });
        
        adminHomePanel.add(btnViewBookings, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 210, 300, 50));
        btnManageNotifications.setBackground(new java.awt.Color(0, 0, 0));
        btnManageNotifications.setForeground(new java.awt.Color(255, 255, 255));
        btnManageNotifications.setText("MANAGE NOTIFICATIONS");
        btnManageNotifications.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnManageNotificationsActionPerformed(evt);
            }
        });
        
        adminHomePanel.add(btnManageNotifications, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 280, 300, 50));

        Background.setToolTipText("");
        adminHomePanel.add(Background, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 740, 400));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(adminHomePanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(adminHomePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }                        

    private void btnLogoutActionPerformed(java.awt.event.ActionEvent evt) {
        // TODO add your handling code here
        this.setVisible(false);
        this.dispose();
        OrderHomeGUI home = new OrderHomeGUI();
        home.setVisible(true);
    }

    private void btnFoodManagementActionPerformed(java.awt.event.ActionEvent evt) {

        ManageFoodGUI foodGUI = new ManageFoodGUI(null);
        this.setVisible(false);
        foodGUI.setVisible(true);
    }

    private void btnVenueManagementActionPerformed(java.awt.event.ActionEvent evt) {

        ManageVenueGUI venueGUI = new ManageVenueGUI(null);
        this.setVisible(false);
        venueGUI.setVisible(true);
    }

    private void btnManageNotificationsActionPerformed(java.awt.event.ActionEvent evt) {
        ManageNotificationsGUI notificationsGUI = new ManageNotificationsGUI(null);
        this.setVisible(false);
        notificationsGUI.setVisible(true);
    }

    private void btnViewBookingsActionPerformed(java.awt.event.ActionEvent evt) {
        BookingHistoryGUI bookingHistoryGUI = new BookingHistoryGUI(null);
        this.setVisible(false);
        bookingHistoryGUI.setVisible(true);
    }

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AdminHomePageGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify                     
    private javax.swing.JLabel Background;
    private javax.swing.JPanel adminHomePanel;
    private javax.swing.JButton btnEquipmentManagement;
    private javax.swing.JButton btnFoodManagement;
    private javax.swing.JButton btnLogout;
    private javax.swing.JButton btnManageNotifications;
    private javax.swing.JButton btnVenueManagement;
    private javax.swing.JButton btnViewBookings;
    private javax.swing.JLabel lblWelcome;
    // End of variables declaration   

}
