/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.order.management.onlineordermanagementsystem.View;

import com.order.management.onlineordermanagementsystem.Model.Customer;

/**
 *
 * @author smacharla
 */
public class CustomerHomeGUI extends javax.swing.JFrame {

    public CustomerHomeGUI() {
        initComponents();

    }

    public CustomerHomeGUI(Customer orderManager) {
        super("CustomerHome");
        setSize(780, 400);
        initComponents();
        setResizable(false); // frame can't be resized
        setLocationRelativeTo(null); // set frame at center of screen
        setDefaultCloseOperation(EXIT_ON_CLOSE);  //default exist when prexx X icon
        this.orderManager = orderManager;
        lblWelcome.setText("Welcome " + orderManager.getName());
        btnUpdatePersonalDetails.setText("<html><br>UPDATE \n PERSONAL DETAILS");

    }

    @SuppressWarnings("unchecked")
                             
    private void initComponents() {

        orderManagerHomePanel = new javax.swing.JPanel();
        lblWelcome = new javax.swing.JLabel();
        btnLogout = new javax.swing.JButton();
        btnViewVenues = new javax.swing.JButton();
        btnViewFoodItems = new javax.swing.JButton();
        btnViewEquipment = new javax.swing.JButton();
        btnBookOrder = new javax.swing.JButton();
        btnBookingHistory = new javax.swing.JButton();
        btnViewNotifications = new javax.swing.JButton();
        btnUpdatePersonalDetails = new javax.swing.JButton();
        background = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        orderManagerHomePanel.setBackground(new java.awt.Color(0, 0, 0));
        orderManagerHomePanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblWelcome.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblWelcome.setForeground(new java.awt.Color(255, 255, 255));
        lblWelcome.setText("WELCOME");
        orderManagerHomePanel.add(lblWelcome, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 15, -1, -1));

        
        btnLogout.setBackground(new java.awt.Color(0, 0, 0));
        btnLogout.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnLogout.setForeground(new java.awt.Color(255, 255, 255));
        btnLogout.setText("LOGOUT");
        btnLogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLogoutActionPerformed(evt);
            }
        });
        orderManagerHomePanel.add(btnLogout, new org.netbeans.lib.awtextra.AbsoluteConstraints(628, 11, 96, -1));

        btnViewVenues.setBackground(new java.awt.Color(0, 0, 0));
        btnViewVenues.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnViewVenues.setForeground(new java.awt.Color(255, 255, 255));
        btnViewVenues.setText("VIEW VENUES");
        btnViewVenues.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnViewVenuesActionPerformed(evt);
            }
        });
        orderManagerHomePanel.add(btnViewVenues, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 300, 300, 50));

        btnViewFoodItems.setBackground(new java.awt.Color(0, 0, 0));
        btnViewFoodItems.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnViewFoodItems.setForeground(new java.awt.Color(255, 255, 255));
        btnViewFoodItems.setText("VIEW FOODITEMS");
        btnViewFoodItems.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnViewFoodItemsActionPerformed(evt);
            }
        });
        orderManagerHomePanel.add(btnViewFoodItems, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 250, 300, 50));

        btnBookOrder.setBackground(new java.awt.Color(0, 0, 0));
        btnBookOrder.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnBookOrder.setForeground(new java.awt.Color(255, 255, 255));
        btnBookOrder.setText("BOOK ORDER");
        btnBookOrder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBookOrderActionPerformed(evt);
            }
        });
        orderManagerHomePanel.add(btnBookOrder, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 200, 300, 50));

        btnBookingHistory.setBackground(new java.awt.Color(0, 0, 0));
        btnBookingHistory.setForeground(new java.awt.Color(255, 255, 255));
        btnBookingHistory.setText("BOOKING HISTORY");
        btnBookingHistory.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBookingHistoryActionPerformed(evt);
            }
        });
        orderManagerHomePanel.add(btnBookingHistory, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 150, 300, 50));

        btnViewNotifications.setBackground(new java.awt.Color(0, 0, 0));
        btnViewNotifications.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnViewNotifications.setForeground(new java.awt.Color(255, 255, 255));
        btnViewNotifications.setText("VIEW NOTIFICATIONS");
        btnViewNotifications.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnViewNotificationsActionPerformed(evt);
            }
        });
        
        orderManagerHomePanel.add(btnViewNotifications, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 50, 300, 50));
        btnUpdatePersonalDetails.setBackground(new java.awt.Color(0, 0, 0));
        btnUpdatePersonalDetails.setForeground(new java.awt.Color(255, 255, 255));
        btnUpdatePersonalDetails.setText("UPDATE INFORMATION");
        btnUpdatePersonalDetails.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdatePersonalDetailsActionPerformed(evt);
            }
        });
        orderManagerHomePanel.add(btnUpdatePersonalDetails, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 100, 300, 50));


        orderManagerHomePanel.add(background, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 760, 400));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(orderManagerHomePanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(orderManagerHomePanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }                       

    private void btnBookingHistoryActionPerformed(java.awt.event.ActionEvent evt) {
        BookingHistoryGUI bookingHistoryGUI = new BookingHistoryGUI(orderManager);
        this.setVisible(false);
        bookingHistoryGUI.setVisible(true);
    }

    private void btnViewVenuesActionPerformed(java.awt.event.ActionEvent evt) {
        ManageVenueGUI venuGUI = new ManageVenueGUI(orderManager);
        this.setVisible(false);
        venuGUI.setVisible(true);
    }

    private void btnViewFoodItemsActionPerformed(java.awt.event.ActionEvent evt) {
        ManageFoodGUI foodGUI = new ManageFoodGUI(orderManager);
        this.setVisible(false);
        foodGUI.setVisible(true);
    }

    private void btnLogoutActionPerformed(java.awt.event.ActionEvent evt) {
        this.setVisible(false);
        this.dispose();
        OrderHomeGUI home = new OrderHomeGUI();
        home.setVisible(true);
    }

    private void btnBookOrderActionPerformed(java.awt.event.ActionEvent evt) {
        BookOrderGUI bookOrderGUI = new BookOrderGUI(orderManager);
        this.setVisible(false);
        bookOrderGUI.setVisible(true);
    }

    private void btnUpdatePersonalDetailsActionPerformed(java.awt.event.ActionEvent evt) {
        UpdateCustomerGUI orderManagerGUI = new UpdateCustomerGUI(orderManager);
        this.setVisible(false);
        orderManagerGUI.setVisible(true);
    }

    private void btnViewNotificationsActionPerformed(java.awt.event.ActionEvent evt) {
        ManageNotificationsGUI notificationsGUI = new ManageNotificationsGUI(orderManager);
        this.setVisible(false);
        notificationsGUI.setVisible(true);
    }

    Customer orderManager;

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CustomerHomeGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify                     
    private javax.swing.JLabel background;
    private javax.swing.JButton btnBookOrder;
    private javax.swing.JButton btnBookingHistory;
    private javax.swing.JButton btnLogout;
    private javax.swing.JButton btnUpdatePersonalDetails;
    private javax.swing.JButton btnViewEquipment;
    private javax.swing.JButton btnViewFoodItems;
    private javax.swing.JButton btnViewNotifications;
    private javax.swing.JButton btnViewVenues;
    private javax.swing.JPanel orderManagerHomePanel;
    private javax.swing.JLabel lblWelcome;
    // End of variables declaration                   
}
