/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.order.management.onlineordermanagementsystem.View;

import com.order.management.onlineordermanagementsystem.Model.Customer;
import com.order.management.onlineordermanagementsystem.Model.Venue;
import com.order.management.onlineordermanagementsystem.controller.DatabaseQueries;
import java.awt.Color;
import java.awt.Image;
import java.io.File;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

/**
 *
 * @author smacharla
 */
public class ManageVenueGUI extends javax.swing.JFrame {

    public ManageVenueGUI() {
        initComponents();
    }

    public ManageVenueGUI(Customer orderManager) {
        super("Venues");
        initComponents();
        show_Venus();
        this.orderManager = orderManager;
        //setSize(871, 500);  //set size of frame
        setResizable(false); // frame can't be resized
        setLocationRelativeTo(null); // set frame at center of screen
        setDefaultCloseOperation(EXIT_ON_CLOSE);  //default exist when prexx X icon
        jTable_Venues.setFillsViewportHeight(true);
        
        jTable_Venues.getTableHeader().setBackground(new Color(255, 255, 255));
        jTable_Venues.getTableHeader().setForeground(Color.BLACK);
        jTable_Venues.getTableHeader().setOpaque(false);

        if (orderManager != null) {
            btnInsertVenue.setVisible(false);
            btnUpdateVenue.setVisible(false);
            btnDeleteVenue.setVisible(false);
            btnClear.setVisible(false);
            btnChooseVenueImage.setVisible(false);
            txtTableType.setEditable(false);
            txtVenuePlace.setEditable(false);
            txtVenuCost.setEditable(false);
            txtTableType.setBackground(new Color(204, 204, 204));
            txtVenuePlace.setBackground(new Color(204, 204, 204));
            txtVenuCost.setBackground(new Color(204, 204, 204));
            lblVenueImage.setBackground(new Color(204, 204, 204));
            lblheading.setText("VIEW VENUES");
            lblWelcome.setText(lblWelcome.getText() + orderManager.getName());
        } else {
            lblWelcome.setText(lblWelcome.getText() + "Admin");
        }
    }

    private void show_Venus() {
        ArrayList<Venue> venues = DatabaseQueries.DDL().selectAllVenues();

        DefaultTableModel model = (DefaultTableModel) jTable_Venues.getModel();
        model.setRowCount(0);
        Object[] row = new Object[5];
        for (int i = 0; i < venues.size(); i++) {
            row[0] = venues.get(i).getVenueID();
            row[1] = venues.get(i).getTableType();
            row[2] = venues.get(i).getVenuePlace();
            row[3] = venues.get(i).getVenueCost();
            row[4] = venues.get(i).getVenueImagePath();
            model.addRow(row);

        }

    }

    @SuppressWarnings("unchecked")
                             
    private void initComponents() {

        venuePanel = new javax.swing.JPanel();
        lblVenueId = new javax.swing.JLabel();
        lblTableType = new javax.swing.JLabel();
        lblVenuePlace = new javax.swing.JLabel();
        lblVenueCost = new javax.swing.JLabel();
        txtVenueID = new javax.swing.JTextField();
        txtTableType = new javax.swing.JTextField();
        txtVenuePlace = new javax.swing.JTextField();
        txtVenuCost = new javax.swing.JTextField();
        lblheading = new javax.swing.JLabel();
        btnInsertVenue = new javax.swing.JButton();
        btnUpdateVenue = new javax.swing.JButton();
        btnDeleteVenue = new javax.swing.JButton();
        btnBack = new javax.swing.JButton();
        jTableScrollPane = new javax.swing.JScrollPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable_Venues = new javax.swing.JTable();
        btnClear = new javax.swing.JButton();
        lblVenueImage = new javax.swing.JLabel();
        btnChooseVenueImage = new javax.swing.JButton();
        lblVenueImagePath = new javax.swing.JLabel();
        lblWelcome = new javax.swing.JLabel();
        background = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        venuePanel.setBackground(new java.awt.Color(0, 0, 0));
        venuePanel.setLayout(null);

        lblVenueId.setBackground(new java.awt.Color(36, 37, 130));
       
        lblVenueId.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblVenueId.setForeground(new java.awt.Color(255, 255, 255));
        lblVenueId.setText("VenueID");
        venuePanel.add(lblVenueId);
        lblVenueId.setBounds(19, 55, 60, 15);
        

        lblTableType.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblTableType.setForeground(new java.awt.Color(255, 255, 255));
        lblTableType.setText("TableType");
        venuePanel.add(lblTableType);
        lblTableType.setBounds(19, 84, 80, 22);

        lblVenuePlace.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblVenuePlace.setForeground(new java.awt.Color(255, 255, 255));
        lblVenuePlace.setText("VenuePlace");
        venuePanel.add(lblVenuePlace);
        lblVenuePlace.setBounds(22, 118, 70, 17);

        lblVenueCost.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblVenueCost.setForeground(new java.awt.Color(255, 255, 255));
        lblVenueCost.setText("VenueCost");
        venuePanel.add(lblVenueCost);
        lblVenueCost.setBounds(23, 154, 70, 15);

        txtVenueID.setEditable(false);
        txtVenueID.setBackground(new java.awt.Color(204, 204, 204));
        
        txtVenueID.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        venuePanel.add(txtVenueID);
        txtVenueID.setBounds(119, 53, 144, 26);
        venuePanel.add(txtTableType);
        txtTableType.setBounds(119, 86, 144, 26);
        venuePanel.add(txtVenuePlace);
        txtVenuePlace.setBounds(119, 117, 144, 26);
        venuePanel.add(txtVenuCost);
        txtVenuCost.setBounds(119, 152, 144, 26);

        lblheading.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lblheading.setForeground(new java.awt.Color(255, 255, 255));
        lblheading.setText("VENUE MANAGEMENT");
        venuePanel.add(lblheading);
        lblheading.setBounds(340, 20, 160, 17);

        
        btnInsertVenue.setBackground(new java.awt.Color(0, 0, 0));
        btnInsertVenue.setForeground(new java.awt.Color(255, 255, 255));
        btnInsertVenue.setText("INSERT");
        btnInsertVenue.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInsertVenueActionPerformed(evt);
            }
        });
        venuePanel.add(btnInsertVenue);
        btnInsertVenue.setBounds(550, 237, 90, 23);

       
        btnUpdateVenue.setBackground(new java.awt.Color(0, 0, 0));
        btnUpdateVenue.setForeground(new java.awt.Color(255, 255, 255));
        btnUpdateVenue.setText("UPDATE");
        btnUpdateVenue.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateVenueActionPerformed(evt);
            }
        });
        venuePanel.add(btnUpdateVenue);
        btnUpdateVenue.setBounds(550, 277, 90, 23);

        
        btnDeleteVenue.setBackground(new java.awt.Color(0, 0, 0));
        btnDeleteVenue.setForeground(new java.awt.Color(255, 255, 255));
        btnDeleteVenue.setText("DELETE");
        btnDeleteVenue.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteVenueActionPerformed(evt);
            }
        });
        venuePanel.add(btnDeleteVenue);
        btnDeleteVenue.setBounds(550, 317, 90, 23);

        btnBack.setBackground(new java.awt.Color(0, 0, 0));
        btnBack.setForeground(new java.awt.Color(255, 255, 255));
        btnBack.setText("BACK");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });
        venuePanel.add(btnBack);
        
        btnBack.setBounds(693, 400, 100, 23);
        jTableScrollPane.setBackground(new java.awt.Color(255, 255, 255));
        jTableScrollPane.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        
        jScrollPane1.setBackground(new java.awt.Color(36, 37, 130));
       
        jScrollPane1.setBorder(null);

        jTable_Venues.setBackground(new java.awt.Color(0, 0, 0));
        jTable_Venues.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jTable_Venues.setForeground(new java.awt.Color(255, 255, 255));
        jTable_Venues.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "VenueID", "TableType", "VenuePlace", "VenueCost", "VenueImage"
            }
        ));
        jTable_Venues.setGridColor(new java.awt.Color(230, 67, 123));
        
        jTable_Venues.setMinimumSize(new java.awt.Dimension(80, 0));
        jTable_Venues.setSelectionBackground(new java.awt.Color(230, 67, 123));
       
        jTable_Venues.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable_VenuesMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable_Venues);
        if (jTable_Venues.getColumnModel().getColumnCount() > 0) {
            jTable_Venues.getColumnModel().getColumn(0).setPreferredWidth(60);
        }
        jTable_Venues.getAccessibleContext().setAccessibleParent(jTableScrollPane);

        jTableScrollPane.setViewportView(jScrollPane1);

        venuePanel.add(jTableScrollPane);
       
        jTableScrollPane.setBounds(24, 200, 459, 240);

        
        btnClear.setBackground(new java.awt.Color(0, 0, 0));
        btnClear.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnClear.setForeground(new java.awt.Color(255, 255, 255));
        btnClear.setText("CLEAR");
        btnClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearActionPerformed(evt);
            }
        });
        venuePanel.add(btnClear);
       
        btnClear.setBounds(670, 114, 130, 23);

        lblVenueImage.setBackground(new java.awt.Color(255, 255, 255));
        lblVenueImage.setForeground(new java.awt.Color(255, 255, 255));
        lblVenueImage.setOpaque(true);
        venuePanel.add(lblVenueImage);
       
        lblVenueImage.setBounds(470, 55, 153, 125);
      
        btnChooseVenueImage.setBackground(new java.awt.Color(0, 0, 0));
        btnChooseVenueImage.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnChooseVenueImage.setForeground(new java.awt.Color(255, 255, 255));
        btnChooseVenueImage.setText("SELECT PICTURE");
        btnChooseVenueImage.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChooseVenueImageActionPerformed(evt);
            }
        });
        venuePanel.add(btnChooseVenueImage);
       
        btnChooseVenueImage.setBounds(670, 74, 130, 23);

        lblVenueImagePath.setBackground(new java.awt.Color(36, 37, 130));
        lblVenueImagePath.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblVenueImagePath.setForeground(new java.awt.Color(255, 255, 255));
        lblVenueImagePath.setText("VenueImage");
        venuePanel.add(lblVenueImagePath);
       
        lblVenueImagePath.setBounds(350, 94, 97, 15);
        lblWelcome.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lblWelcome.setForeground(new java.awt.Color(255, 255, 255));
        lblWelcome.setText("Welcome ");
        venuePanel.add(lblWelcome);
        lblWelcome.setBounds(10, 10, 160, 17);


        venuePanel.add(background);
        background.setBounds(0, 0, 870, 460);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(venuePanel, javax.swing.GroupLayout.PREFERRED_SIZE, 871, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(venuePanel, javax.swing.GroupLayout.PREFERRED_SIZE, 459, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }                     

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {                                        
        this.setVisible(false);
        this.dispose();
        if (btnInsertVenue.isVisible()) {
            AdminHomePageGUI home = new AdminHomePageGUI();
            home.setVisible(true);
        } else {
            CustomerHomeGUI home = new CustomerHomeGUI(orderManager);
            home.setVisible(true);
        }
    }                                       

    @SuppressWarnings("empty-statement")
    private void btnInsertVenueActionPerformed(java.awt.event.ActionEvent evt) {                                               
        String name = txtTableType.getText();
        String place = txtVenuePlace.getText();
        String cost = txtVenuCost.getText();
        String validationMessage = "";

        
        if (name.trim().isEmpty()) {
            validationMessage += "Name is Empty";
        }

        if (place.trim().isEmpty()) {
            validationMessage += "\nPlace is Empty";
        }

        if (cost.trim().isEmpty()) {
            validationMessage += "\nCost is Empty";
        }

        if (venueImagePath.trim().isEmpty()) {
            validationMessage += "\nVenue Image is Empty";
        }

        if (validationMessage != "") {
            JOptionPane.showMessageDialog(null, validationMessage); // show message
            return; // end method
        }
        if (!cost.matches("[0-9]+([,.][0-9]{1,2})?")) {
            JOptionPane.showMessageDialog(null, "Invalid cost"); // show message
            return; // end method
        }

        ArrayList<Venue> venues = DatabaseQueries.DDL().selectAllVenues();
        for (Venue venue : venues) {
            if (name.equals(venue.getTableType())) {
                JOptionPane.showMessageDialog(this, "Table Type already exist in system"); // then show error meesage
                return;
            }
        }

        Venue vn = new Venue(name, place, Double.parseDouble(cost), venueImagePath);
        vn.setVenueID(DatabaseQueries.DML().InsertVenue(vn));
        txtVenueID.setText("" + vn.getVenueID());
        JOptionPane.showMessageDialog(null, "Venue inserted successfully");
        show_Venus();
    }                                              

    private void btnUpdateVenueActionPerformed(java.awt.event.ActionEvent evt) {                                               
        String id = txtVenueID.getText();
        String name = txtTableType.getText();
        String place = txtVenuePlace.getText();
        String cost = txtVenuCost.getText();
        String validationMessage = "";
        if (name.trim().isEmpty()) {
            validationMessage += "Name is Empty";
        }

        if (place.trim().isEmpty()) {
            validationMessage += "\nPlace is Empty";
        }

        if (cost.trim().isEmpty()) {
            validationMessage += "\nCost is Empty";
        }

        if (venueImagePath.trim().isEmpty()) {
            validationMessage += "\nVenue Image is Empty";
        }

        if (validationMessage != "") {
            JOptionPane.showMessageDialog(null, validationMessage); // show message
            return; // end method
        }
        if (!cost.matches("^[0-9]*(.+)$")) {
            JOptionPane.showMessageDialog(null, "Invalid cost"); // show message
            return; // end method
        }

        Venue vn = new Venue(Integer.parseInt(id), name, place, Double.parseDouble(cost), venueImagePath);
        DatabaseQueries.DML().UpdateVenue(vn);
        JOptionPane.showMessageDialog(null, "Venue updated successfully");
        show_Venus();
    }                                              

    private void btnDeleteVenueActionPerformed(java.awt.event.ActionEvent evt) {                                               
        String id = txtVenueID.getText();
        DatabaseQueries.DML().DeleteVenue(Integer.parseInt(id));
        JOptionPane.showMessageDialog(null, "Venue deleted successfully"); // show message
        show_Venus();
        txtVenueID.setText("");
        txtTableType.setText("");
        txtVenuePlace.setText("");
        txtVenuCost.setText("");
        venueImagePath = "";
        lblVenueImage.setIcon(null);
    }                                              

    private void btnClearActionPerformed(java.awt.event.ActionEvent evt) {                                         
        txtVenueID.setText("");
        txtTableType.setText("");
        txtVenuePlace.setText("");
        txtVenuCost.setText("");
        venueImagePath = "";
        lblVenueImage.setIcon(null);

    }                                        

    String venueImagePath;

    private void btnChooseVenueImageActionPerformed(java.awt.event.ActionEvent evt) {                                                    
        JFileChooser file = new JFileChooser();
        file.setCurrentDirectory(new File(System.getProperty("user.dir") + "\\src\\Icons\\Venues"));
        FileNameExtensionFilter filter = new FileNameExtensionFilter("*.images", "jpg", "png");
        file.addChoosableFileFilter(filter);
        int result = file.showSaveDialog(null);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = file.getSelectedFile();
            String path = selectedFile.getAbsolutePath();
            lblVenueImage.setIcon(resizeImage(path));
            venueImagePath = path;
        } else {
            lblVenueImage.setText("No file choosen");
        }
    }                                                   

    private void jTable_VenuesMouseClicked(java.awt.event.MouseEvent evt) {                                           
        int i = jTable_Venues.getSelectedRow();
        TableModel model = jTable_Venues.getModel();
        txtVenueID.setText(model.getValueAt(i, 0).toString());
        txtTableType.setText(model.getValueAt(i, 1).toString());
        txtVenuePlace.setText(model.getValueAt(i, 2).toString());
        txtVenuCost.setText(model.getValueAt(i, 3).toString());
        if (model.getValueAt(i, 4) == null) {
            venueImagePath = "";
            lblVenueImage.setIcon(null);
        } else {
            venueImagePath = model.getValueAt(i, 4).toString();
            lblVenueImage.setIcon(resizeImage(model.getValueAt(i, 4).toString()));
        }
    }                                          

    public ImageIcon resizeImage(String imagePath) {
        ImageIcon venueImage = new ImageIcon(imagePath);
        Image img = venueImage.getImage().getScaledInstance(lblVenueImage.getWidth(), lblVenueImage.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon venueFixedImage = new ImageIcon(img);
        return venueFixedImage;
    }

    Customer orderManager;

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ManageVenueGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify                     
    private javax.swing.JLabel background;
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnChooseVenueImage;
    private javax.swing.JButton btnClear;
    private javax.swing.JButton btnDeleteVenue;
    private javax.swing.JButton btnInsertVenue;
    private javax.swing.JButton btnUpdateVenue;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jTableScrollPane;
    private javax.swing.JTable jTable_Venues;
    private javax.swing.JLabel lblVenueCost;
    private javax.swing.JLabel lblVenueId;
    private javax.swing.JLabel lblVenueImage;
    private javax.swing.JLabel lblVenueImagePath;
    private javax.swing.JLabel lblTableType;
    private javax.swing.JLabel lblVenuePlace;
    private javax.swing.JLabel lblWelcome;
    private javax.swing.JLabel lblheading;
    private javax.swing.JTextField txtVenuCost;
    private javax.swing.JTextField txtVenueID;
    private javax.swing.JTextField txtTableType;
    private javax.swing.JTextField txtVenuePlace;
    private javax.swing.JPanel venuePanel;
    // End of variables declaration            
    
}
