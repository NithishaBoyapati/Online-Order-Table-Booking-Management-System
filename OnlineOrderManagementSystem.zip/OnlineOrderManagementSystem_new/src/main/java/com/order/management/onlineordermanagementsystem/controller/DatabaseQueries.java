package com.order.management.onlineordermanagementsystem.controller;

/**
 *
 * @author smacharla
 */
public abstract class DatabaseQueries extends DBConnection {

    public static DDL_Queries DDL() {
        return DDL_Queries.getInst();
    }

    public static DML_Queries DML() {
        return DML_Queries.getInst();
    }

}