/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.order.management.onlineordermanagementsystem.View;

import com.order.management.onlineordermanagementsystem.Model.Customer;
import com.order.management.onlineordermanagementsystem.controller.DatabaseQueries;
import java.awt.Color;
import java.util.ArrayList;
import javax.swing.DefaultComboBoxModel;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import javax.swing.JOptionPane;

/**
 *
 * @author smacharla
 */
public class UpdateCustomerGUI extends javax.swing.JFrame {
    
    

    public UpdateCustomerGUI() {
        initComponents();
     
        
    }

    public UpdateCustomerGUI(Customer orderManager) {
        super("UpdateCustomer");
        initComponents();
        this.orderManager = orderManager;
        setResizable(false); // frame can't be resized
        setLocationRelativeTo(null); // set frame at center of screen
        setDefaultCloseOperation(EXIT_ON_CLOSE);  //default exist when prexx X icon
        lblWelcome.setText(lblWelcome.getText() + orderManager.getName());
        this.orderManager = orderManager;
        ArrayList<String> genderValues = DatabaseQueries.DDL().selectGender();
        cmbGender.setModel(new DefaultComboBoxModel(genderValues.toArray()));

        txtName.setText(orderManager.getName());
        txtMobile.setText(orderManager.getMobile());
        txtEmailAddress.setText(orderManager.getEmail());
        txtAddress.setText(orderManager.getAddress());
        chkSubscribe.setSelected((orderManager.getSubscribe() == 1 ? true : false));
        cmbGender.setSelectedItem(orderManager.getGender());
    }

    @SuppressWarnings("unchecked")
                           
    private void initComponents() {

        updateOrderManagerPanel = new javax.swing.JPanel();
        lblName = new javax.swing.JLabel();
        txtName = new javax.swing.JTextField();
        lblMobile = new javax.swing.JLabel();
        cmbGender = new javax.swing.JComboBox<>();
        lblGender = new javax.swing.JLabel();
        lblEmailAddress = new javax.swing.JLabel();
        lblAddress = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtAddress = new javax.swing.JTextArea();
        chkSubscribe = new javax.swing.JCheckBox();
        lblWelcome = new javax.swing.JLabel();
        btnUpdate = new javax.swing.JButton();
        txtMobile = new javax.swing.JTextField();
        txtEmailAddress = new javax.swing.JTextField();
        lblAlert = new javax.swing.JLabel();
        btnBack = new javax.swing.JButton();
        background = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        updateOrderManagerPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        updateOrderManagerPanel.setBackground(new java.awt.Color(0, 0, 0));

        lblName.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lblName.setForeground(new java.awt.Color(255, 255, 255));
        lblName.setText("Name");
        updateOrderManagerPanel.add(lblName, new org.netbeans.lib.awtextra.AbsoluteConstraints(48, 59, -1, -1));
        updateOrderManagerPanel.add(txtName, new org.netbeans.lib.awtextra.AbsoluteConstraints(153, 56, 160, -1));

        lblMobile.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lblMobile.setForeground(new java.awt.Color(255, 255, 255));
        lblMobile.setText("Mobile");
        updateOrderManagerPanel.add(lblMobile, new org.netbeans.lib.awtextra.AbsoluteConstraints(383, 59, -1, -1));

        updateOrderManagerPanel.add(cmbGender, new org.netbeans.lib.awtextra.AbsoluteConstraints(153, 94, 160, -1));

        lblGender.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lblGender.setForeground(new java.awt.Color(255, 255, 255));
        lblGender.setText("Gender");
        updateOrderManagerPanel.add(lblGender, new org.netbeans.lib.awtextra.AbsoluteConstraints(48, 97, -1, -1));

        lblEmailAddress.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lblEmailAddress.setForeground(new java.awt.Color(255, 255, 255));
        lblEmailAddress.setText("EmailAddress");
        updateOrderManagerPanel.add(lblEmailAddress, new org.netbeans.lib.awtextra.AbsoluteConstraints(383, 97, -1, -1));

        lblAddress.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lblAddress.setForeground(new java.awt.Color(255, 255, 255));
        lblAddress.setText("Address");
        
        updateOrderManagerPanel.add(lblAddress, new org.netbeans.lib.awtextra.AbsoluteConstraints(158, 152, -1, -1));
        
        jScrollPane1.setBackground(new java.awt.Color(0, 0, 0));

        txtAddress.setColumns(20);
        txtAddress.setRows(5);
        jScrollPane1.setViewportView(txtAddress);

       
        updateOrderManagerPanel.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(253, 152, -1, -1));
        chkSubscribe.setForeground(new java.awt.Color(255, 255, 255));
        chkSubscribe.setText("Subscribe to Notifications");
        chkSubscribe.setOpaque(false);
        updateOrderManagerPanel.add(chkSubscribe, new org.netbeans.lib.awtextra.AbsoluteConstraints(36, 276, -1, -1));

        lblWelcome.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblWelcome.setForeground(new java.awt.Color(255, 255, 255));
        lblWelcome.setText("Welcome ");
        updateOrderManagerPanel.add(lblWelcome, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 11, 113, -1));

       
        btnUpdate.setBackground(new java.awt.Color(0, 0, 0));
        btnUpdate.setForeground(new java.awt.Color(255, 255, 255));
        btnUpdate.setText("UPDATE");
        btnUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateActionPerformed(evt);
            }
        });
        updateOrderManagerPanel.add(btnUpdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(315, 277, 100, -1));
        updateOrderManagerPanel.add(txtMobile, new org.netbeans.lib.awtextra.AbsoluteConstraints(486, 56, 151, -1));
        updateOrderManagerPanel.add(txtEmailAddress, new org.netbeans.lib.awtextra.AbsoluteConstraints(486, 94, 151, -1));

        lblAlert.setForeground(new java.awt.Color(255, 255, 255));
        lblAlert.setText("*Customers need to update their information manually");
        updateOrderManagerPanel.add(lblAlert, new org.netbeans.lib.awtextra.AbsoluteConstraints(36, 348, 601, -1));

        btnBack.setBackground(new java.awt.Color(0, 0, 0));
        btnBack.setForeground(new java.awt.Color(255, 255, 255));
        btnBack.setText("BACK");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });
        updateOrderManagerPanel.add(btnBack, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 330, -1, -1));


        updateOrderManagerPanel.add(background, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 750, 410));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(updateOrderManagerPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 740, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(updateOrderManagerPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }                      

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {                                          
        String name = txtName.getText();
        String mobile = txtMobile.getText();
        String email = txtEmailAddress.getText();
        String address = txtAddress.getText();
        String gender = cmbGender.getSelectedItem().toString();

        String validationMessage = "";
        if (name.trim().isEmpty()) {
            validationMessage += "Name is Empty";
        }

        if (mobile.trim().isEmpty()) {
            validationMessage += "\nMobile is Empty";
        }

        if (email.trim().isEmpty()) {
            validationMessage += "\nEmail is Empty";
        }

        if (address.trim().isEmpty()) {
            validationMessage += "\nAddress is Empty";
        }

        if (validationMessage != "") {
            JOptionPane.showMessageDialog(null, validationMessage);
            return;
        }
        if (!email.matches("^(.+)@(.+)$")) {
            JOptionPane.showMessageDialog(null, "Invalid Email");
            return;
        }
        if (!mobile.matches("^[0-9]*$")) {
            JOptionPane.showMessageDialog(null, "Invalid Mobile");
            return;
        }

        int subscribe = chkSubscribe.isSelected() ? 1 : 0;
        Customer em = new Customer(orderManager.getCustomerID(), name, mobile, email, address, orderManager.getPassword(), gender, subscribe);
        DatabaseQueries.DML().UpdateOrderManager(em);
        JOptionPane.showMessageDialog(this, "Details got updated successfully");
    }                                         

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {                                        
        this.setVisible(false);
        this.dispose();
        CustomerHomeGUI home = new CustomerHomeGUI(orderManager);
        home.setVisible(true);
    }                                       

    Customer orderManager;

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new UpdateCustomerGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify                     
    private javax.swing.JLabel background;
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnUpdate;
    private javax.swing.JCheckBox chkSubscribe;
    private javax.swing.JComboBox<String> cmbGender;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblAddress;
    private javax.swing.JLabel lblAlert;
    private javax.swing.JLabel lblEmailAddress;
    private javax.swing.JLabel lblGender;
    private javax.swing.JLabel lblMobile;
    private javax.swing.JLabel lblName;
    private javax.swing.JLabel lblWelcome;
    private javax.swing.JTextArea txtAddress;
    private javax.swing.JTextField txtEmailAddress;
    private javax.swing.JTextField txtMobile;
    private javax.swing.JTextField txtName;
    private javax.swing.JPanel updateOrderManagerPanel;
    // End of variables declaration                   
    
}
