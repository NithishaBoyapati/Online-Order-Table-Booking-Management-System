/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.order.management.onlineordermanagementsystem.Model;

/**
 *
 * @author smacharla
 */
public class Customer {
    
    private int customerID;
    private String name;
    private String mobile;
    private String email;
    private String address;
    private String password;
    private String gender;
    private int subscribe;

    public Customer(int customerID, String name, String mobile, String email, String address, String password, String gender, int subscribe) {
        this.customerID = customerID;
        this.name = name;
        this.mobile = mobile;
        this.email = email;
        this.address = address;
        this.password = password;
        this.gender = gender;
        this.subscribe = subscribe;
    }

    public Customer(String name, String mobile, String email, String address, String password, String gender, int subscribe) {
        this.name = name;
        this.mobile = mobile;
        this.email = email;
        this.address = address;
        this.password = password;
        this.gender = gender;
        this.subscribe = subscribe;
    }

    public int getCustomerID() {
        return customerID;
    }

    public void setCustomerID(int customerID) {
        this.customerID = customerID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public int getSubscribe() {
        return subscribe;
    }

    public void setSubscribe(int subscribe) {
        this.subscribe = subscribe;
    }
    
    public void update(String message) {
        System.out.println("Updating Order Manager " + message);
    }

    
}
