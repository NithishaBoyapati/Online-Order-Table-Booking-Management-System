/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.order.management.onlineordermanagementsystem.View;

import com.order.management.onlineordermanagementsystem.Model.Admin;
import com.order.management.onlineordermanagementsystem.Model.Notification;
import com.order.management.onlineordermanagementsystem.Model.Customer;
import com.order.management.onlineordermanagementsystem.controller.DatabaseQueries;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;


/**
 *
 * @author smacharla
 */

public class ManageNotificationsGUI extends javax.swing.JFrame {
     public ManageNotificationsGUI() {
        initComponents();
    }

    public ManageNotificationsGUI(Customer orderManager) {
        super("Notifications");
        initComponents();
        setSize(732, 420);
        setResizable(false); // frame can't be resized
        setLocationRelativeTo(null); // set frame at center of screen
        setDefaultCloseOperation(EXIT_ON_CLOSE);  //default exist when prexx X icon
        this.orderManager = orderManager;
        jTable_Notifications.setFillsViewportHeight(true);
        
        jTable_Notifications.getTableHeader().setBackground(new Color(255, 255, 255));
        jTable_Notifications.getTableHeader().setForeground(Color.BLACK);
        jTable_Notifications.getTableHeader().setOpaque(false);

        if (orderManager != null) {
            txtMessage.setEnabled(false);
            txtMessage.setBackground(new Color(204, 204, 204));
            btnSend.setVisible(false);
            btnClear.setVisible(false);
            lblWelcome.setText(lblWelcome.getText() + " " +orderManager.getName());
            lblHeading.setText("VIEW NOTIFICATIONS");
        } else {
            lblWelcome.setText(lblWelcome.getText() + "Admin");

        }

        show_Notifications();
    }

    private void show_Notifications() {
        ArrayList<Notification> notifications = DatabaseQueries.DDL().selectAllNotifications();

        if (orderManager != null) {
            for (int i = 0; i < notifications.size(); i++) {
                Notification notification = notifications.get(i);
                if (notification.getCustomerID() != orderManager.getCustomerID()) {
                    notifications.remove(i);
                }
            }
        } else {
            notifications = DatabaseQueries.DDL().selectDistinctNotifications();
        }
        DefaultTableModel model = (DefaultTableModel) jTable_Notifications.getModel();
        model.setRowCount(0);
        Object[] row = new Object[2];
        for (int i = 0; i < notifications.size(); i++) {
            row[0] = notifications.get(i).getMessage();
            row[1] = notifications.get(i).getSentDate();
            model.addRow(row);
        }

    }

    @SuppressWarnings("unchecked")
                          
    private void initComponents() {

        notificationsPanel = new javax.swing.JPanel();
        scrollMessage = new javax.swing.JScrollPane();
        txtMessage = new javax.swing.JTextArea();
        lblWelcome = new javax.swing.JLabel();
        btnSend = new javax.swing.JButton();
        scrolVerticallNotifications = new javax.swing.JScrollPane();
        scrollHorizontalNotifications = new javax.swing.JScrollPane();
        jTable_Notifications = new javax.swing.JTable();
        lblInfo = new javax.swing.JLabel();
        btnBack = new javax.swing.JButton();
        lblHeading = new javax.swing.JLabel();
        btnClear = new javax.swing.JButton();
        background = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        notificationsPanel.setBackground(new java.awt.Color(0, 0, 0));
        notificationsPanel.setLayout(null);

   
        txtMessage.setBackground(new java.awt.Color(255, 255, 255));
        txtMessage.setColumns(20);
        txtMessage.setLineWrap(true);
        txtMessage.setRows(3);
        txtMessage.setWrapStyleWord(true);
        txtMessage.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        scrollMessage.setViewportView(txtMessage);

        notificationsPanel.add(scrollMessage);
        scrollMessage.setBounds(500, 119, 220, 100);

        lblWelcome.setBackground(new java.awt.Color(36, 37, 130));
        lblWelcome.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblWelcome.setForeground(new java.awt.Color(255, 255, 255));
        lblWelcome.setText("WELCOME");
        notificationsPanel.add(lblWelcome);
        lblWelcome.setBounds(20, 14, 304, 15);

      
        btnSend.setBackground(new java.awt.Color(0, 0, 0));
        btnSend.setForeground(new java.awt.Color(255, 255, 255));
        btnSend.setText("SEND ");
        btnSend.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSendActionPerformed(evt);
            }
        });
        notificationsPanel.add(btnSend);
        btnSend.setBounds(525, 230, 80, 23);

        jTable_Notifications.setBackground(new java.awt.Color(0, 0, 0));
        jTable_Notifications.setForeground(new java.awt.Color(255, 255, 255));
        jTable_Notifications.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "NotificationMessage", "SentOn"
            }
        ));
        jTable_Notifications.setGridColor(new java.awt.Color(230, 67, 123));
        jTable_Notifications.setSelectionBackground(new java.awt.Color(230, 67, 123));
        jTable_Notifications.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable_NotificationsMouseClicked(evt);
            }
        });
        scrollHorizontalNotifications.setViewportView(jTable_Notifications);
        if (jTable_Notifications.getColumnModel().getColumnCount() > 0) {
            jTable_Notifications.getColumnModel().getColumn(0).setPreferredWidth(200);
            jTable_Notifications.getColumnModel().getColumn(1).setPreferredWidth(30);
        }

        scrolVerticallNotifications.setViewportView(scrollHorizontalNotifications);

        notificationsPanel.add(scrolVerticallNotifications);
       
        scrolVerticallNotifications.setBounds(34, 90, 430, 273);
        lblInfo.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        lblInfo.setForeground(new java.awt.Color(255, 255, 255));
        lblInfo.setText("*Notifications will only be sent to the subscribed usres/customers");
        notificationsPanel.add(lblInfo);
        lblInfo.setBounds(35, 65, 400, 15);

        btnBack.setBackground(new java.awt.Color(0, 0, 0));
        btnBack.setForeground(new java.awt.Color(255, 255, 255));
        btnBack.setText("BACK");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });
        notificationsPanel.add(btnBack);
        btnBack.setBounds(628, 350, 70, 23);

        lblHeading.setBackground(new java.awt.Color(36, 37, 130));
        lblHeading.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lblHeading.setForeground(new java.awt.Color(255, 255, 255));
        lblHeading.setText("MANAGE NOTIFICATIONS");
        notificationsPanel.add(lblHeading);
        lblHeading.setBounds(288, 12, 200, 17);

       
        btnClear.setBackground(new java.awt.Color(0, 0, 0));
        btnClear.setForeground(new java.awt.Color(255, 255, 255));
        btnClear.setText("CLEAR");
        btnClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearActionPerformed(evt);
            }
        });
        notificationsPanel.add(btnClear);
        btnClear.setBounds(620, 230, 80, 23);


        notificationsPanel.add(background);
        background.setBounds(0, -60, 740, 470);

        getContentPane().add(notificationsPanel);
        notificationsPanel.setBounds(2, -1, 750, 410);

        pack();
    }                      

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {                                        
        this.setVisible(false);
        this.dispose();
        if (btnSend.isVisible()) {
            AdminHomePageGUI home = new AdminHomePageGUI();
            home.setVisible(true);
        } else {
            CustomerHomeGUI home = new CustomerHomeGUI(orderManager);
            home.setVisible(true);
        }
    }                                       

    private void btnSendActionPerformed(java.awt.event.ActionEvent evt) {                                        

        if (txtMessage.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Message is empty");
            return;
        }

        String message = txtMessage.getText().trim();
        Admin admin = new Admin();
        ArrayList<Customer> orderManagers = DatabaseQueries.DDL().selectAllOrderManagers();
        admin.setOrderManagers(orderManagers);

        for (int i = 0; i < admin.getOrderManagers().size(); i++) {
            Customer orderManager = admin.getOrderManagers().get(i);
            if (orderManager.getSubscribe() == 1) //sending message to only subscribed users
            {
                orderManager.update(message + " to order manager:" + orderManager.getCustomerID() + " " + orderManager.getName());
                Notification notification = new Notification(orderManager.getCustomerID(), message, new java.sql.Date(new Date().getTime()));
                DatabaseQueries.DML().InsertNotification(notification);
            }
        }

        JOptionPane.showMessageDialog(null, "Notifications sent to all subscribed Customers");
        show_Notifications();
    }                                       

    private void jTable_NotificationsMouseClicked(java.awt.event.MouseEvent evt) {                                                  
        int i = jTable_Notifications.getSelectedRow();
        TableModel model = jTable_Notifications.getModel();
        txtMessage.setText(model.getValueAt(i, 0).toString());
    }                                                 

    private void btnClearActionPerformed(java.awt.event.ActionEvent evt) {                                         
        txtMessage.setText("");
    }                                        

    Customer orderManager = null;

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ManageNotificationsGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify                     
    private javax.swing.JLabel background;
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnClear;
    private javax.swing.JButton btnSend;
    private javax.swing.JTable jTable_Notifications;
    private javax.swing.JLabel lblHeading;
    private javax.swing.JLabel lblInfo;
    private javax.swing.JLabel lblWelcome;
    private javax.swing.JPanel notificationsPanel;
    private javax.swing.JScrollPane scrolVerticallNotifications;
    private javax.swing.JScrollPane scrollHorizontalNotifications;
    private javax.swing.JScrollPane scrollMessage;
    private javax.swing.JTextArea txtMessage;
    // End of variables declaration                   
}

    


