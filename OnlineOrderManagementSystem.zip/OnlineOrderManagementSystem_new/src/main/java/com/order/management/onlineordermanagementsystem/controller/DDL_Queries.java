package com.order.management.onlineordermanagementsystem.controller;

/**
 *
 * @author smacharla
 */
import com.order.management.onlineordermanagementsystem.Model.Admin;
import com.order.management.onlineordermanagementsystem.Model.FoodItem;
import com.order.management.onlineordermanagementsystem.Model.FoodOrder;
import com.order.management.onlineordermanagementsystem.Model.Notification;
import com.order.management.onlineordermanagementsystem.Model.Customer;
import com.order.management.onlineordermanagementsystem.Model.Venue;
import java.awt.Event;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class DDL_Queries extends DatabaseQueries implements DDL_Interface {

    protected PreparedStatement pst = null;
    protected Statement st = null;
    protected ResultSet rs = null;

    private static DDL_Queries inst;

    public static DDL_Queries getInst() {
        if (inst == null) {
            inst = new DDL_Queries();
        }
        return inst;
    }

    @Override
    public ArrayList<Customer> selectAllOrderManagers() {
        try {
            String query = "SELECT * FROM ORDERMANAGEMENTDB.ORDERMANAGER ";
            ArrayList<Customer> orderManagers = new ArrayList<>();
            st = getConnection().createStatement();
            rs = st.executeQuery(query);
            while (rs.next()) {
                int customerID = rs.getInt(1);
                String name = rs.getString(2);
                String mobile = rs.getString(3);
                String email = rs.getString(4);
                String address = rs.getString(5);
                String password = rs.getString(6);
                String gender = rs.getString(7);
                int subscribe = rs.getInt(8);
                Customer orderManager = new Customer(customerID, name, mobile, email, address, password, gender, subscribe);
                orderManagers.add(orderManager);
            }
            return orderManagers;
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public Admin selectAdminPwd(String ID) {

        try {
            String query = "SELECT * FROM ORDERMANAGEMENTDB.ADMIN where adminid='" + ID + "'";
            st = getConnection().createStatement();
            rs = st.executeQuery(query);
            Admin admin = null;
            while (rs.next()) {
                String adminID = rs.getString(1);
                String pwd = rs.getString(2);
                admin = new Admin(adminID, pwd);
            }
            return admin;
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;
    }

    public ArrayList<String> selectGender() {
        try {
            String query = "SELECT Name FROM ORDERMANAGEMENTDB.GENDER ";
            ArrayList<String> genderValues = new ArrayList<>();
            st = getConnection().createStatement();
            rs = st.executeQuery(query);
            while (rs.next()) {
                String gender = rs.getString(1);
                genderValues.add(gender);
            }
            return genderValues;
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;
    }

    @Override
    public ArrayList<String> selectAllVenueTypes() {
        try {
            String query = "SELECT * FROM ORDERMANAGEMENTDB.VENUETYPE ";
            ArrayList<String> venueTypes = new ArrayList<>();
            st = getConnection().createStatement();
            rs = st.executeQuery(query);
            while (rs.next()) {
                String venueType = rs.getString(1);
                venueTypes.add(venueType);
            }
            return venueTypes;
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;
    }

    @Override
    public Customer selectOrderManagerDetails(int ID) {
        try {
            String query = "SELECT * FROM ordermanagementdb.ordermanager where customerid= " + ID;
            st = getConnection().createStatement();
            rs = st.executeQuery(query);
            Customer orderManager = null;
            while (rs.next()) {
                int customerID = rs.getInt(1);
                String name = rs.getString(2);
                String mobile = rs.getString(3);
                String email = rs.getString(4);
                String address = rs.getString(5);
                String password = rs.getString(6);
                String gender = rs.getString(7);
                int subscribe = rs.getInt(8);

                orderManager = new Customer(customerID, name, mobile, email, address, password, gender, subscribe);
            }
            return orderManager;

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;
    }

    @Override
    public ArrayList<Venue> selectAllVenues() {
        try {
            String query = "SELECT * FROM ORDERMANAGEMENTDB.VENUE ";
            st = getConnection().createStatement();
            rs = st.executeQuery(query);
            ArrayList<Venue> venues = new ArrayList<>();
            while (rs.next()) {
                int venueID = rs.getInt(1);
                String tableType = rs.getString(2);
                String venuePlace = rs.getString(3);
                double venueCost = rs.getDouble(4);
                String venueImagePath = rs.getString(5);

                Venue venue = new Venue(venueID, tableType, venuePlace, venueCost, venueImagePath);

                venues.add(venue);
            }
            return venues;

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;
    }

    @Override
    public ArrayList<FoodItem> selectAllFoodItems() {
        try {
            String query = "SELECT * FROM ORDERMANAGEMENTDB.FOODITEMS ";
            st = getConnection().createStatement();
            rs = st.executeQuery(query);
            ArrayList<FoodItem> foodItems = new ArrayList<>();
            while (rs.next()) {
                int foodItemID = rs.getInt(1);
                String foodItemName = rs.getString(2);
                double foodItemCost = rs.getDouble(3);
                String foodItemImagePath = rs.getString(4);

                FoodItem foodItem = new FoodItem(foodItemID, foodItemName, foodItemCost, foodItemImagePath);

                foodItems.add(foodItem);
            }
            return foodItems;

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;
    }

    @Override
    public ArrayList<FoodOrder> selectAllFoodOrders() {
        try {
            String query = "SELECT * FROM ORDERMANAGEMENTDB.ORDER ";
            ArrayList<FoodOrder> foodOrders = new ArrayList<>();
            st = getConnection().createStatement();
            rs = st.executeQuery(query);
            while (rs.next()) {
                int foodOrderID = rs.getInt(1);
                int customerID = rs.getInt(2);
                String orderType = rs.getString(3);
                String tableType = rs.getString(4);
                String venueType = rs.getString(5);
                Date orderDate = rs.getDate(6);
                String orderTime = rs.getString(7);
                String foodItems = rs.getString(8);
                int guestsCount = rs.getInt(9);
                double venueCost = rs.getDouble(10);
                double foodItemsCost = rs.getDouble(11);
                double orderCost = rs.getDouble(12);
                String paymentStatus = rs.getString(13);
                FoodOrder foodOrder = new FoodOrder(foodOrderID, customerID, orderType, tableType, venueType, orderDate,orderTime, foodItems, guestsCount, venueCost, foodItemsCost, orderCost, paymentStatus);

                foodOrders.add(foodOrder);
            }
            return foodOrders;
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;
    }

    @Override
    public ArrayList<Notification> selectAllNotifications() {
        try {
            String query = "SELECT * FROM ordermanagementdb.Notifications ";
            ArrayList<Notification> notifications = new ArrayList<>();
            st = getConnection().createStatement();
            rs = st.executeQuery(query);
            while (rs.next()) {
                int customerID = rs.getInt(1);
                String message = rs.getString(2);
                Date sentDate = rs.getDate(3);

                Notification notification = new Notification(customerID, message, sentDate);
                notifications.add(notification);
            }
            return notifications;
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;
    }

    @Override
    public ArrayList<Notification> selectDistinctNotifications() {
        try {
            String query = "SELECT distinct message,sentdate FROM ordermanagementdb.notifications;";
            ArrayList<Notification> notifications = new ArrayList<>();
            st = getConnection().createStatement();
            rs = st.executeQuery(query);
            while (rs.next()) {
                int customerID = 0;
                String message = rs.getString(1);
                Date sentDate = rs.getDate(2);
                Notification notification = new Notification(customerID, message, sentDate);
                notifications.add(notification);
            }
            return notifications;
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;
    }
    
    @Override
    public ArrayList<String> selectAllOrderTypes() {
        try {
            String query = "SELECT * FROM  ORDERMANAGEMENTDB.Ordertype ";
            ArrayList<String> eventTypes = new ArrayList<>();
            st = getConnection().createStatement();
            rs = st.executeQuery(query);
            while (rs.next()) {
                String eventType = rs.getString(1);
                eventTypes.add(eventType);
            }
            return eventTypes;
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return null;
    }
}
