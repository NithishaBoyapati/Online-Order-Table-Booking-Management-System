/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.order.management.onlineordermanagementsystem.View;

import com.order.management.onlineordermanagementsystem.Model.Customer;
import com.order.management.onlineordermanagementsystem.controller.DatabaseQueries;
import java.awt.Color;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

/**
 *
 * @author smacharla
 */
public class CustomerLoginGUI extends javax.swing.JPanel {

    public CustomerLoginGUI() {
        initComponents();
        orderManagerScroll.getViewport().setOpaque(false);
        orderManagerScroll.setOpaque(false);
        orderManagerScroll.setBorder(null);

        jTextArea1.setOpaque(false);
        jTextArea1.setBackground(new Color(0, 0, 0));
    }

    @SuppressWarnings("unchecked")
                            
    private void initComponents() {

        lblCustomerID = new javax.swing.JLabel();
        txtCustomerID = new javax.swing.JTextField();
        lblPassword = new javax.swing.JLabel();
        txtPassword = new javax.swing.JPasswordField();
        btnSubmit = new javax.swing.JButton();
        btnCancel = new javax.swing.JButton();
        poolImage = new javax.swing.JLabel();
        birthdayImage = new javax.swing.JLabel();
        orderManagerScroll = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        background = new javax.swing.JLabel();

        
        setBackground(new java.awt.Color(0, 0, 0));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblCustomerID.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblCustomerID.setForeground(new java.awt.Color(255, 255, 255));
        lblCustomerID.setText("Customer ID");
        
        add(lblCustomerID, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 170, -1, -1));

        txtCustomerID.setMinimumSize(new java.awt.Dimension(20, 20));
       
        add(txtCustomerID, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 170, 131, -1));

        lblPassword.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblPassword.setForeground(new java.awt.Color(255, 255, 255));
        lblPassword.setText("Password");
      
        add(lblPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 220, -1, -1));
       
        add(txtPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 220, 131, -1));
        btnSubmit.setBackground(new java.awt.Color(0, 0, 0));
        btnSubmit.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnSubmit.setForeground(new java.awt.Color(255, 255, 255));
        btnSubmit.setText("SUBMIT");
        btnSubmit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSubmitActionPerformed(evt);
            }
        });
        
        add(btnSubmit, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 270, -1, -1));

        btnCancel.setBackground(new java.awt.Color(0, 0, 0));
        btnCancel.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnCancel.setForeground(new java.awt.Color(255, 255, 255));
        btnCancel.setText("CANCEL");
        btnCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelActionPerformed(evt);
            }
        });
       
        add(btnCancel, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 270, -1, -1));

        add(poolImage, new org.netbeans.lib.awtextra.AbsoluteConstraints(379, 193, 340, 178));


        add(birthdayImage, new org.netbeans.lib.awtextra.AbsoluteConstraints(21, 193, 340, -1));

        orderManagerScroll.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        orderManagerScroll.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);
        orderManagerScroll.setOpaque(false);

        jTextArea1.setEditable(false);
        jTextArea1.setColumns(20);
        jTextArea1.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jTextArea1.setForeground(new java.awt.Color(255, 255, 255));
        jTextArea1.setLineWrap(true);
        jTextArea1.setRows(5);
        jTextArea1.setText("Order operations and logistics is where all the time spent. Planning the order comes together in the execution of the order. Save your time by booking for any order Online using our system");
        jTextArea1.setWrapStyleWord(true);
        orderManagerScroll.setViewportView(jTextArea1);

        
        add(orderManagerScroll, new org.netbeans.lib.awtextra.AbsoluteConstraints(59, 50, 680, 500));

        add(background, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 740, 400));
    }                       

    private void btnSubmitActionPerformed(java.awt.event.ActionEvent evt) {
        String customerID = txtCustomerID.getText();
        String password = txtPassword.getText();

        //Validations
        if (customerID.isEmpty() || password.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "CustomerID or Password is Empty");
            return;
        }
        //Validation for ID
        if (!customerID.matches("^[0-9]*$")) {
            JOptionPane.showMessageDialog(null, "Invalid CustomerID");
            return;
        }

        Customer orderManager = DatabaseQueries.DDL().selectOrderManagerDetails(Integer.parseInt(customerID));

        if (orderManager != null && orderManager.getPassword() != null && password.equals(orderManager.getPassword())) {
            // JOptionPane.showMessageDialog(this, "Login Succesfull");
            this.setVisible(false);
            SwingUtilities.windowForComponent(this).dispose();
            new CustomerHomeGUI(orderManager).setVisible(true); // open the home page
            return;
        } else {
            //if no match found then show message for not found
            JOptionPane.showMessageDialog(this, "CustomerID and Password either not found.");
            return;
        }
    }

    private void btnCancelActionPerformed(java.awt.event.ActionEvent evt) {
        txtCustomerID.setText("");
        txtPassword.setText("");
    }

    // Variables declaration - do not modify                     
    private javax.swing.JLabel background;
    private javax.swing.JLabel birthdayImage;
    private javax.swing.JButton btnCancel;
    private javax.swing.JButton btnSubmit;
    private javax.swing.JScrollPane orderManagerScroll;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JLabel lblCustomerID;
    private javax.swing.JLabel lblPassword;
    private javax.swing.JLabel poolImage;
    private javax.swing.JTextField txtCustomerID;
    private javax.swing.JPasswordField txtPassword;
    // End of variables declaration                   
}
