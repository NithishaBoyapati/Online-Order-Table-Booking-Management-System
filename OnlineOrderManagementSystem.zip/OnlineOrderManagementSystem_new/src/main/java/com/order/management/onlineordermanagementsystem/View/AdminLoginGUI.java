/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.order.management.onlineordermanagementsystem.View;

import com.order.management.onlineordermanagementsystem.Model.Admin;
import com.order.management.onlineordermanagementsystem.controller.DatabaseQueries;
import java.awt.Color;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

/**
 *
 * @author smacharla
 */
public class AdminLoginGUI extends javax.swing.JPanel {

    public AdminLoginGUI() {
        initComponents();
        AdminInfoScroll.getViewport().setOpaque(false);
        AdminInfoScroll.setOpaque(false);
        AdminInfoScroll.setBorder(null);

        txtAdminInfo.setOpaque(false);
        txtAdminInfo.setBackground(new Color(0, 0, 0));

    }

    @SuppressWarnings("unchecked")
                             
    private void initComponents() {

        lblAdminID = new javax.swing.JLabel();
        lblPassword = new javax.swing.JLabel();
        txtAdminID = new javax.swing.JTextField();
        txtPassword = new javax.swing.JPasswordField();
        btnSubmit = new javax.swing.JButton();
        btnCancel = new javax.swing.JButton();
        AdminInfoScroll = new javax.swing.JScrollPane();
        txtAdminInfo = new javax.swing.JTextArea();
        CorporateImage = new javax.swing.JLabel();
        WeddingImage = new javax.swing.JLabel();
        Backgorund = new javax.swing.JLabel();

        setBackground(new java.awt.Color(0, 0, 0));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblAdminID.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblAdminID.setForeground(new java.awt.Color(255, 255, 255));
        lblAdminID.setText("AdminID");
        
        add(lblAdminID, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 170, -1, -1));
        lblPassword.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblPassword.setForeground(new java.awt.Color(255, 255, 255));
        lblPassword.setText("Password");
        
        add(lblPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 220, -1, -1));
        
        add(txtAdminID, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 170, 131, -1));
       
        add(txtPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 220, 131, -1));

        btnSubmit.setBackground(new java.awt.Color(0, 0, 0));
        btnSubmit.setForeground(new java.awt.Color(255, 255, 255));
        btnSubmit.setText("Submit");
        btnSubmit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSubmitActionPerformed(evt);
            }
        });
       
        add(btnSubmit, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 270, -1, -1));
        btnCancel.setBackground(new java.awt.Color(0, 0, 0));
        btnCancel.setForeground(new java.awt.Color(255, 255, 255));
        btnCancel.setText("Cancel");
        btnCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelActionPerformed(evt);
            }
        });
        //add(btnCancel, new org.netbeans.lib.awtextra.AbsoluteConstraints(191, 142, -1, -1));
        add(btnCancel, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 270, -1, -1));
        AdminInfoScroll.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        AdminInfoScroll.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);
        AdminInfoScroll.setOpaque(false);

        txtAdminInfo.setColumns(5000);
        txtAdminInfo.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        txtAdminInfo.setForeground(new java.awt.Color(255, 255, 255));
        txtAdminInfo.setLineWrap(true);
        txtAdminInfo.setRows(50);
      
        txtAdminInfo.setText(" The role of an admin would be managing and distributing information within a restaurant. \nIn this restaurant admin will be responsible for managing food items, venue (place customer wants his/her table to be) and bookings of a customer \n\n The messages sent form an admin in the form of notifications will only be received by the subscribed customers.");
        txtAdminInfo.setWrapStyleWord(true);
        txtAdminInfo.setOpaque(false);
        AdminInfoScroll.setViewportView(txtAdminInfo);

        
        add(AdminInfoScroll, new org.netbeans.lib.awtextra.AbsoluteConstraints(59, 50, 680, 500));

        
        add(CorporateImage, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 190, 390, 200));

      
        add(WeddingImage, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 190, 320, 200));


        add(Backgorund, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 740, 410));
    }                      

    private void btnSubmitActionPerformed(java.awt.event.ActionEvent evt) {
        String adminID = txtAdminID.getText();
        String password = txtPassword.getText();

        //check if ID or password are empty
        if (adminID.isEmpty() || password.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "AdminID or Password is Empty");
            return; // end method
        }

        Admin admin = DatabaseQueries.DDL().selectAdminPwd(adminID);

        if (admin.getPassword() != null && password.equals(admin.getPassword())) {
            //Login Succesfull
            this.setVisible(false);
            SwingUtilities.windowForComponent(this).dispose();
            new AdminHomePageGUI().setVisible(true);
            return;
        } else {
            //if no match found then show message for not found
            JOptionPane.showMessageDialog(this, "AdminID and Password either not found.");
        }
    }

    private void btnCancelActionPerformed(java.awt.event.ActionEvent evt) {
        txtAdminID.setText("");
        txtPassword.setText("");
    }

    // Variables declaration - do not modify                     
    private javax.swing.JScrollPane AdminInfoScroll;
    private javax.swing.JLabel Backgorund;
    private javax.swing.JLabel CorporateImage;
    private javax.swing.JLabel WeddingImage;
    private javax.swing.JButton btnCancel;
    private javax.swing.JButton btnSubmit;
    private javax.swing.JLabel lblAdminID;
    private javax.swing.JLabel lblPassword;
    private javax.swing.JTextField txtAdminID;
    private javax.swing.JTextArea txtAdminInfo;
    private javax.swing.JPasswordField txtPassword;
    // End of variables declaration                 

}
