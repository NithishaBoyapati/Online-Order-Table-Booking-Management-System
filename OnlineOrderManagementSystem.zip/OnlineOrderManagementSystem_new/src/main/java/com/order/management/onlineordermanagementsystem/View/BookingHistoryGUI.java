/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.order.management.onlineordermanagementsystem.View;

import com.order.management.onlineordermanagementsystem.Model.FoodOrder;
import com.order.management.onlineordermanagementsystem.Model.Customer;
import com.order.management.onlineordermanagementsystem.Model.Venue;
import com.order.management.onlineordermanagementsystem.controller.DatabaseQueries;
import java.util.ArrayList;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

/**
 *
 * @author smacharla
 */
public class BookingHistoryGUI extends javax.swing.JFrame {

    public BookingHistoryGUI() {
        initComponents();
    }

    ArrayList<FoodOrder> foodOrders;
    ArrayList<Venue> venues;
    
    public BookingHistoryGUI(Customer orderManager) {
         super("BookingHistory");
        initComponents();
      
        this.orderManager = orderManager;
        jTable_Events.setAutoResizeMode(jTable_Events.AUTO_RESIZE_OFF);
        show_Orders();
        setResizable(false); // frame can't be resized
        setLocationRelativeTo(null); // set frame at center of screen
        setDefaultCloseOperation(EXIT_ON_CLOSE);  //default exist when prexx X icon
        jTable_Events.setFillsViewportHeight(true);

        if (orderManager==null) {
            lblWelcome.setText(lblWelcome.getText() + "Admin");
            btnPayForEvent.setVisible(false);
        }else{
              lblWelcome.setText(lblWelcome.getText() + orderManager.getName());
        }

    }

    private void show_Orders() {
        foodOrders = DatabaseQueries.DDL().selectAllFoodOrders();
        if (orderManager!=null) {
            for (int i = 0; i < foodOrders.size(); i++) {
                FoodOrder foodOrder = foodOrders.get(i);
                if (foodOrder.getFoodCustomerID() != orderManager.getCustomerID()) {
                    foodOrders.remove(i);
                }
            }
        }
        DefaultTableModel model = (DefaultTableModel) jTable_Events.getModel();
        model.setRowCount(0);
        Object[] row = new Object[13];
        for (int i = 0; i < foodOrders.size(); i++) {
            row[0] = foodOrders.get(i).getBookingID();
            row[1] = foodOrders.get(i).getFoodCustomerID();
            row[2] = foodOrders.get(i).getFoodOrderType();
            row[3] = foodOrders.get(i).getTableType();
            row[4] = foodOrders.get(i).getVenueType();
            row[5] = foodOrders.get(i).getFoodOrderDate();
            row[6] = foodOrders.get(i).getOrderTime();
            row[7] = foodOrders.get(i).getFoodItems();
            row[8] = foodOrders.get(i).getGuestsCount();
            row[9] = foodOrders.get(i).getVenueCost();
            row[10] = foodOrders.get(i).getFoodItemsCost();
            row[11] = foodOrders.get(i).getFoodOrderCost();
            row[12] = foodOrders.get(i).getPaymentStatus();
            model.addRow(row);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    private void initComponents() {

        pnlBookingHistory = new javax.swing.JPanel();
        btnPayForEvent = new javax.swing.JButton();
        lblBookingID = new javax.swing.JLabel();
        txtBookingID = new javax.swing.JTextField();
        bookingHistoryScroll = new javax.swing.JScrollPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable_Events = new javax.swing.JTable();
        btnBack = new javax.swing.JButton();
        lblWelcome = new javax.swing.JLabel();
        lblHeading = new javax.swing.JLabel();
        background = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        pnlBookingHistory.setBackground(new java.awt.Color(0, 0, 0));
        pnlBookingHistory.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnPayForEvent.setBackground(new java.awt.Color(0, 0, 0));
        btnPayForEvent.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnPayForEvent.setForeground(new java.awt.Color(255, 255, 255));
        btnPayForEvent.setText("Pay for Order");
        btnPayForEvent.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPayForEventActionPerformed(evt);
            }
        });
        pnlBookingHistory.add(btnPayForEvent, new org.netbeans.lib.awtextra.AbsoluteConstraints(763, 49, 120, -1));

        lblBookingID.setBackground(new java.awt.Color(36, 37, 130));
        lblBookingID.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblBookingID.setForeground(new java.awt.Color(255, 255, 255));
        lblBookingID.setText("BookingID");
        pnlBookingHistory.add(lblBookingID, new org.netbeans.lib.awtextra.AbsoluteConstraints(25, 55, 67, -1));

        txtBookingID.setEditable(false);
        txtBookingID.setBackground(new java.awt.Color(204, 204, 204));
        txtBookingID.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        pnlBookingHistory.add(txtBookingID, new org.netbeans.lib.awtextra.AbsoluteConstraints(96, 49, 98, -1));

        jTable_Events.setBackground(new java.awt.Color(0, 0, 0));
        jTable_Events.setForeground(new java.awt.Color(255, 255, 255));
        jTable_Events.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "BookingID", "CustomerID", "OrderType", "TableType", "VenueType", "OrderDate", "OrderTime", "FoodItems", "Guests", "VenueCost","FoodItemsCost", "OrderCost", "PaymentStatus"
            }
        ));
        jTable_Events.setGridColor(new java.awt.Color(230, 67, 123));
        jTable_Events.setSelectionBackground(new java.awt.Color(230, 67, 123));
        jTable_Events.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable_EventsMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable_Events);

        bookingHistoryScroll.setViewportView(jScrollPane1);

        pnlBookingHistory.add(bookingHistoryScroll, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 90, 858, 276));

        btnBack.setBackground(new java.awt.Color(0, 0, 0));
        btnBack.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnBack.setForeground(new java.awt.Color(255, 255, 255));
        btnBack.setText("BACK");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });
        pnlBookingHistory.add(btnBack, new org.netbeans.lib.awtextra.AbsoluteConstraints(763, 20, 120, -1));

        lblWelcome.setBackground(new java.awt.Color(36, 37, 130));
        lblWelcome.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblWelcome.setForeground(new java.awt.Color(255, 255, 255));
        lblWelcome.setText("Welcome ");
        pnlBookingHistory.add(lblWelcome, new org.netbeans.lib.awtextra.AbsoluteConstraints(25, 24, 112, -1));

        lblHeading.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lblHeading.setForeground(new java.awt.Color(255, 255, 255));
        lblHeading.setText("BOOKING HISTORY");
        pnlBookingHistory.add(lblHeading, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 20, -1, -1));


        pnlBookingHistory.add(background, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 910, 400));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlBookingHistory, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlBookingHistory, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }                       

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {                                        

        this.setVisible(false);
        this.dispose();
        if (!btnPayForEvent.isVisible()) {
            AdminHomePageGUI home = new AdminHomePageGUI();
            this.dispose();
            home.setVisible(true);
        } else {
            CustomerHomeGUI home = new CustomerHomeGUI(orderManager);
            this.dispose();
            home.setVisible(true);
        }
    }                                       

    private void jTable_EventsMouseClicked(java.awt.event.MouseEvent evt) {                                           
        int i = jTable_Events.getSelectedRow();
        TableModel model = jTable_Events.getModel();
        txtBookingID.setText(model.getValueAt(i, 0).toString());
    }                                          

    private void btnPayForEventActionPerformed(java.awt.event.ActionEvent evt) {                                               
        // TODO add your handling code here:
        if (txtBookingID.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please select the foodOrder you want to pay for."); // show message
            return; // end method
        }

        //Based on the BookingID select the foodOrder
        FoodOrder foodOrder = null;
        for (int i = 0; i < foodOrders.size(); i++) {
            if (foodOrders.get(i).getBookingID() == Integer.parseInt(txtBookingID.getText().trim())) {
                foodOrder = foodOrders.get(i);
            }
        }
        if (foodOrder.getPaymentStatus().equals("Completed")) {
            JOptionPane.showMessageDialog(null, "Payment is completed for the foodOrder selected.");
            return;
        }

        //Based on venue name select the venue
        Venue venue = null;
        venues = DatabaseQueries.DDL().selectAllVenues();
        for (int i = 0; i < venues.size(); i++) {
            if (venues.get(i).getTableType().equals(foodOrder.getTableType())) {
                venue = venues.get(i);
            }
        }
        
        if(venue==null)
        {
            JOptionPane.showMessageDialog(null, "Venue of this foodOrder no longer exists. Please book another foodOrder.");
            return;
        }
        

        OrderPaymentGUI paymentGUI = new OrderPaymentGUI(orderManager, venue, foodOrder);
        this.dispose();
        paymentGUI.setVisible(true);
    }                                              

    
    Customer orderManager;

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(BookingHistoryGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(BookingHistoryGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(BookingHistoryGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(BookingHistoryGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new BookingHistoryGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify                     
    private javax.swing.JLabel background;
    private javax.swing.JScrollPane bookingHistoryScroll;
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnPayForEvent;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable_Events;
    private javax.swing.JLabel lblBookingID;
    private javax.swing.JLabel lblHeading;
    private javax.swing.JLabel lblWelcome;
    private javax.swing.JPanel pnlBookingHistory;
    private javax.swing.JTextField txtBookingID;
    // End of variables declaration                   
}
