package com.order.management.onlineordermanagementsystem.View;

import com.order.management.onlineordermanagementsystem.Model.FoodItem;
import com.order.management.onlineordermanagementsystem.Model.Customer;
import com.order.management.onlineordermanagementsystem.controller.DatabaseQueries;
import java.awt.Color;
import java.awt.Image;
import java.io.File;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

/**
 *
 * @author smacharla
 */
public class ManageFoodGUI extends javax.swing.JFrame {

    public ManageFoodGUI() {
        initComponents();
    }

    public ManageFoodGUI(Customer customer) {
        super("FoodItems");
        initComponents();
        this.customer = customer;
        show_FoodItems();
        //setSize(813, 432);  //set size of frame
        setResizable(false); // frame can't be resized
        setLocationRelativeTo(null); // set frame at center of screen
        setDefaultCloseOperation(EXIT_ON_CLOSE);  //default exist when prexx X icon
        jTable_FoodItems.setFillsViewportHeight(true);
        if (customer != null) {
            btnInsertFoodItem.setVisible(false);
            btnUpdateFoodItem.setVisible(false);
            btnDeleteFoodItem.setVisible(false);
            btnClear.setVisible(false);
            btnChooseImageFoodItem.setVisible(false);
            txtFoodItemName.setEditable(false);
            txtFoodItemCost.setEditable(false);
            txtFoodItemName.setBackground(new Color(204, 204, 204));
            txtFoodItemCost.setBackground(new Color(204, 204, 204));
            lblFoodItemImage.setBackground(new Color(204, 204, 204));
            lblheading.setText("VIEW FOODITEMS");
            lblWelcome.setText(lblWelcome.getText() + customer.getName());
        } else {
            lblWelcome.setText(lblWelcome.getText() + "Admin");
        }

    }

    private void show_FoodItems() {
        ArrayList<FoodItem> foodItems = DatabaseQueries.DDL().selectAllFoodItems();

        DefaultTableModel model = (DefaultTableModel) jTable_FoodItems.getModel();
        model.setRowCount(0);
        Object[] row = new Object[4];
        for (int i = 0; i < foodItems.size(); i++) {
            row[0] = foodItems.get(i).getFoodItemId();
            row[1] = foodItems.get(i).getFoodItemName();
            row[2] = foodItems.get(i).getFoodItemCost();
            row[3] = foodItems.get(i).getFoodImagePath();
            model.addRow(row);
        }

    }

    @SuppressWarnings("unchecked")
                            
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        foodPanel = new javax.swing.JPanel();
        lblheading = new javax.swing.JLabel();
        btnBack = new javax.swing.JButton();
        lblFoodItemID = new javax.swing.JLabel();
        txtFoodItemID = new javax.swing.JTextField();
        lblFoodItemName = new javax.swing.JLabel();
        txtFoodItemName = new javax.swing.JTextField();
        lblFoodItemCost = new javax.swing.JLabel();
        txtFoodItemCost = new javax.swing.JTextField();
        btnInsertFoodItem = new javax.swing.JButton();
        btnUpdateFoodItem = new javax.swing.JButton();
        btnDeleteFoodItem = new javax.swing.JButton();
        lblFoodImage = new javax.swing.JLabel();
        lblFoodItemImage = new javax.swing.JLabel();
        foodItemsScroll = new javax.swing.JScrollPane();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable_FoodItems = new javax.swing.JTable();
        btnClear = new javax.swing.JButton();
        btnChooseImageFoodItem = new javax.swing.JButton();
        lblWelcome = new javax.swing.JLabel();
        background = new javax.swing.JLabel();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        foodPanel.setBackground(new java.awt.Color(0, 0, 0));
        foodPanel.setLayout(null);

        lblheading.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lblheading.setForeground(new java.awt.Color(255, 255, 255));
        lblheading.setText("FOOD MANAGEMENT");
        foodPanel.add(lblheading);
        lblheading.setBounds(314, 13, 147, 17);

        btnBack.setBackground(new java.awt.Color(0, 0, 0));
        btnBack.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnBack.setForeground(new java.awt.Color(255, 255, 255));
        btnBack.setText("BACK");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });
        foodPanel.add(btnBack);
        btnBack.setBounds(693, 400, 100, 23);
        

        lblFoodItemID.setBackground(new java.awt.Color(36, 37, 130));
        lblFoodItemID.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblFoodItemID.setForeground(new java.awt.Color(255, 255, 255));
        lblFoodItemID.setText("FoodItemID");
        foodPanel.add(lblFoodItemID);
        lblFoodItemID.setBounds(24, 46, 73, 15);

        txtFoodItemID.setEditable(false);
        
        txtFoodItemID.setBackground(new java.awt.Color(255, 255, 255));
        txtFoodItemID.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        foodPanel.add(txtFoodItemID);
        txtFoodItemID.setBounds(127, 44, 153, 20);

        lblFoodItemName.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblFoodItemName.setForeground(new java.awt.Color(255, 255, 255));
        lblFoodItemName.setText("FoodItemName");
        foodPanel.add(lblFoodItemName);
        lblFoodItemName.setBounds(24, 84, 92, 15);
        foodPanel.add(txtFoodItemName);
        txtFoodItemName.setBounds(127, 82, 153, 20);

        lblFoodItemCost.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblFoodItemCost.setForeground(new java.awt.Color(255, 255, 255));
        lblFoodItemCost.setText("FoodItemCost");
        foodPanel.add(lblFoodItemCost);
        lblFoodItemCost.setBounds(20, 120, 90, 15);
        foodPanel.add(txtFoodItemCost);
        txtFoodItemCost.setBounds(127, 121, 153, 20);

        
        btnInsertFoodItem.setBackground(new java.awt.Color(0, 0, 0));
        btnInsertFoodItem.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnInsertFoodItem.setForeground(new java.awt.Color(255, 255, 255));
        btnInsertFoodItem.setText("INSERT");
        btnInsertFoodItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInsertFoodItemActionPerformed(evt);
            }
        });
        foodPanel.add(btnInsertFoodItem);
        btnInsertFoodItem.setBounds(550, 227, 90, 23);

      
        btnUpdateFoodItem.setBackground(new java.awt.Color(0, 0, 0));
        btnUpdateFoodItem.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnUpdateFoodItem.setForeground(new java.awt.Color(255, 255, 255));
        btnUpdateFoodItem.setText("UPDATE");
        btnUpdateFoodItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateFoodItemActionPerformed(evt);
            }
        });
        foodPanel.add(btnUpdateFoodItem);
        btnUpdateFoodItem.setBounds(550, 267, 90, 23);

        
        btnDeleteFoodItem.setBackground(new java.awt.Color(0, 0, 0));
        btnDeleteFoodItem.setForeground(new java.awt.Color(255, 255, 255));
        btnDeleteFoodItem.setText("DELETE");
        btnDeleteFoodItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteFoodItemActionPerformed(evt);
            }
        });
        foodPanel.add(btnDeleteFoodItem);
        btnDeleteFoodItem.setBounds(550, 307, 90, 23);

        lblFoodImage.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblFoodImage.setForeground(new java.awt.Color(255, 255, 255));
        lblFoodImage.setText("FoodItemImage");
        foodPanel.add(lblFoodImage);
        
        lblFoodImage.setBounds(350, 94, 97, 15);
        lblFoodItemImage.setBackground(new java.awt.Color(255, 255, 255));
        lblFoodItemImage.setForeground(new java.awt.Color(255, 255, 255));
        lblFoodItemImage.setOpaque(true);
        foodPanel.add(lblFoodItemImage);
        
        lblFoodItemImage.setBounds(470, 44, 153, 125);
        
        foodItemsScroll.setBackground(new java.awt.Color(36, 37, 130));

        jTable_FoodItems.setBackground(new java.awt.Color(0, 0, 0));
        jTable_FoodItems.setForeground(new java.awt.Color(255, 255, 255));
        jTable_FoodItems.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "FoodItemID", "FoodItemName", "FoodItemCost", "FoodItemImage"
            }
        ));
        jTable_FoodItems.setGridColor(new java.awt.Color(230, 67, 123));
        jTable_FoodItems.setSelectionBackground(new java.awt.Color(230, 67, 123));
        jTable_FoodItems.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable_FoodItemsMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(jTable_FoodItems);

        foodItemsScroll.setViewportView(jScrollPane3);

        foodPanel.add(foodItemsScroll);
        
        foodItemsScroll.setBounds(24, 180, 459, 240);

        
        btnClear.setBackground(new java.awt.Color(0, 0, 0));
        btnClear.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnClear.setForeground(new java.awt.Color(255, 255, 255));
        btnClear.setText("CLEAR");
        btnClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearActionPerformed(evt);
            }
        });
        foodPanel.add(btnClear);
        btnClear.setBounds(670, 114, 130, 23);

      
        btnChooseImageFoodItem.setBackground(new java.awt.Color(0, 0, 0));
        btnChooseImageFoodItem.setForeground(new java.awt.Color(255, 255, 255));
        btnChooseImageFoodItem.setText("SELECT PICTURE");
        btnChooseImageFoodItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChooseImageFoodItemActionPerformed(evt);
            }
        });
        foodPanel.add(btnChooseImageFoodItem);
        btnChooseImageFoodItem.setBounds(670, 74, 130, 23);

        lblWelcome.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lblWelcome.setForeground(new java.awt.Color(255, 255, 255));
        lblWelcome.setText("Welcome ");
        foodPanel.add(lblWelcome);
        lblWelcome.setBounds(20, 10, 130, 14);


        foodPanel.add(background);
        background.setBounds(0, 0, 830, 460);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(foodPanel, javax.swing.GroupLayout.DEFAULT_SIZE, 831, Short.MAX_VALUE)
                .addGap(0, 0, 0))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(foodPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 457, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }                       

    private void btnUpdateFoodItemActionPerformed(java.awt.event.ActionEvent evt) {                                                  
        String id = txtFoodItemID.getText();
        String name = txtFoodItemName.getText();
        String cost = txtFoodItemCost.getText();

        String validationMessage = "";
        if (name.trim().isEmpty()) {
            validationMessage += "Name is Empty";
        }

        if (cost.trim().isEmpty()) {
            validationMessage += "\nCost is Empty";
        }

        if (foodItemImagePath.trim().isEmpty()) {
            validationMessage += "\nFoodItem Image is Empty";
        }

        if (validationMessage != "") {
            JOptionPane.showMessageDialog(null, validationMessage);
            return; // end method
        }
        if (!cost.matches("^[0-9]*(.+)$")) {
            JOptionPane.showMessageDialog(null, "Invalid cost");
            return; // end method
        }
        FoodItem foodItem = new FoodItem(Integer.parseInt(id), name, Double.parseDouble(cost), foodItemImagePath);
        DatabaseQueries.DML().UpdateFoodItem(foodItem);
        JOptionPane.showMessageDialog(null, "FoodItem updated successfully");
        show_FoodItems();
    }                                                 

    private void btnClearActionPerformed(java.awt.event.ActionEvent evt) {                                         
        txtFoodItemID.setText("");
        txtFoodItemName.setText("");
        txtFoodItemCost.setText("");
        foodItemImagePath = "";
        lblFoodItemImage.setIcon(null);
    }                                        

    private void btnInsertFoodItemActionPerformed(java.awt.event.ActionEvent evt) {                                                  
        String name = txtFoodItemName.getText();
        String cost = txtFoodItemCost.getText();

        String validationMessage = "";
        if (name.trim().isEmpty()) {
            validationMessage += "Name is Empty";
        }

        if (cost.trim().isEmpty()) {
            validationMessage += "\nCost is Empty";
        }

        if (foodItemImagePath.trim().isEmpty()) {
            validationMessage += "\nFoodItem Image is Empty";
        }

        if (validationMessage != "") {
            JOptionPane.showMessageDialog(null, validationMessage);
            return; // end method
        }
        if (!cost.matches("[0-9]+([,.][0-9]{1,2})?")) {
            JOptionPane.showMessageDialog(null, "Invalid cost");
            return; // end method
        }

        ArrayList<FoodItem> foodItems = DatabaseQueries.DDL().selectAllFoodItems();
        for (FoodItem foodItem : foodItems) {
            if (name.equals(foodItem.getFoodItemName())) {
                JOptionPane.showMessageDialog(this, "Food Item already exist in system");
                return;
            }
        }

        FoodItem foodItem = new FoodItem(name, Double.parseDouble(cost), foodItemImagePath);
        foodItem.setFoodItemId(DatabaseQueries.DML().InsertFoodItem(foodItem));
        txtFoodItemID.setText("" + foodItem.getFoodItemId());
        JOptionPane.showMessageDialog(null, "FoodItem inserted successfully");
        show_FoodItems();
    }                                                 

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {                                        
        this.setVisible(false);
        this.dispose();
        if (btnInsertFoodItem.isVisible()) {
            AdminHomePageGUI home = new AdminHomePageGUI();
            home.setVisible(true);
        } else {
            CustomerHomeGUI home = new CustomerHomeGUI(customer);
            home.setVisible(true);
        }
    }                                       

    String foodItemImagePath = "";
    private void btnChooseImageFoodItemActionPerformed(java.awt.event.ActionEvent evt) {                                                       
        JFileChooser file = new JFileChooser();
        file.setCurrentDirectory(new File(System.getProperty("user.dir") + "\\src\\Icons\\FoodItems"));
        FileNameExtensionFilter filter = new FileNameExtensionFilter("*.images", "jpg", "png");
        file.addChoosableFileFilter(filter);
        int result = file.showSaveDialog(null);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = file.getSelectedFile();
            String path = selectedFile.getAbsolutePath();
            lblFoodItemImage.setIcon(resizeImage(path));
            foodItemImagePath = path;
        } else {
            lblFoodItemImage.setText("No file choosen");
        }
    }                                                      

    private void btnDeleteFoodItemActionPerformed(java.awt.event.ActionEvent evt) {                                                  
        String id = txtFoodItemID.getText();
        DatabaseQueries.DML().DeleteFoodItem(Integer.parseInt(id));
        JOptionPane.showMessageDialog(null, "Food Item deleted successfully");
        show_FoodItems();
        txtFoodItemID.setText("");
        txtFoodItemName.setText("");
        txtFoodItemCost.setText("");
        foodItemImagePath = "";
        lblFoodItemImage.setIcon(null);
    }                                                 

    private void jTable_FoodItemsMouseClicked(java.awt.event.MouseEvent evt) {                                              
        int i = jTable_FoodItems.getSelectedRow();
        TableModel model = jTable_FoodItems.getModel();
        txtFoodItemID.setText(model.getValueAt(i, 0).toString());
        txtFoodItemName.setText(model.getValueAt(i, 1).toString());
        txtFoodItemCost.setText(model.getValueAt(i, 2).toString());
        if (model.getValueAt(i, 3) == null) {
            foodItemImagePath = "";
            lblFoodItemImage.setIcon(null);
        } else {
            foodItemImagePath = model.getValueAt(i, 3).toString();
            lblFoodItemImage.setIcon(resizeImage(model.getValueAt(i, 3).toString()));
        }
    }                                             
    
    private ImageIcon resizeImage(String imagePath) {
        ImageIcon foodItemImage = new ImageIcon(imagePath);
        Image img = foodItemImage.getImage().getScaledInstance(lblFoodItemImage.getWidth(), lblFoodItemImage.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon foodItemFixedImage = new ImageIcon(img);
        return foodItemFixedImage;
    }

    Customer customer;

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ManageFoodGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify                     
    private javax.swing.JLabel background;
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnChooseImageFoodItem;
    private javax.swing.JButton btnClear;
    private javax.swing.JButton btnDeleteFoodItem;
    private javax.swing.JButton btnInsertFoodItem;
    private javax.swing.JButton btnUpdateFoodItem;
    private javax.swing.JScrollPane foodItemsScroll;
    private javax.swing.JPanel foodPanel;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable_FoodItems;
    private javax.swing.JLabel lblFoodImage;
    private javax.swing.JLabel lblFoodItemCost;
    private javax.swing.JLabel lblFoodItemID;
    private javax.swing.JLabel lblFoodItemImage;
    private javax.swing.JLabel lblFoodItemName;
    private javax.swing.JLabel lblWelcome;
    private javax.swing.JLabel lblheading;
    private javax.swing.JTextField txtFoodItemCost;
    private javax.swing.JTextField txtFoodItemID;
    private javax.swing.JTextField txtFoodItemName;
    // End of variables declaration                   
}
