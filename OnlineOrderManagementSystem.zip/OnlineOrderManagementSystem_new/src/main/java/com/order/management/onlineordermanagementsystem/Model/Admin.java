package com.order.management.onlineordermanagementsystem.Model;

import java.util.ArrayList;

/**
 *
 * @author smacharla
 */
public class Admin {

    private String adminID;
    private String password;
    private ArrayList<Customer> orderManagers;

    public Admin()
    {
        
    }

    public Admin(String adminID, String password) {
        this.adminID = adminID;
        this.password = password;
    }

    public String getAdminID() {
        return adminID;
    }

    public void setAdminID(String adminID) {
        this.adminID = adminID;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
     public ArrayList<Customer> getOrderManagers() {
        return orderManagers;
    }

    public void setOrderManagers(ArrayList<Customer> orderManagers) {
        this.orderManagers = orderManagers;
    }

}
