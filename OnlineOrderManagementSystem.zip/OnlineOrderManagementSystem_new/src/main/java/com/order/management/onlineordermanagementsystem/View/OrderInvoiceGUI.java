/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.order.management.onlineordermanagementsystem.View;

import com.order.management.onlineordermanagementsystem.Model.FoodOrder;
import com.order.management.onlineordermanagementsystem.Model.Customer;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.text.SimpleDateFormat;
import java.util.Date;
import static javax.swing.JFrame.EXIT_ON_CLOSE;

/**
 *
 * @author smacharla
 */
public class OrderInvoiceGUI extends javax.swing.JFrame {
    
    

    public OrderInvoiceGUI() {
        initComponents();
    }

    public OrderInvoiceGUI(Customer orderManager, FoodOrder order) {
         super("OrderInvoice");
        initComponents();
        setResizable(false); // frame can't be resized
        setLocationRelativeTo(null); // set frame at center of screen
        setDefaultCloseOperation(EXIT_ON_CLOSE);  //default exist when prexx X icon
        this.orderManager = orderManager;
        orderTypeScrollPane.setBorder(null);
        venueScrollPane.setBorder(null);
        txtCustomerID.setText(txtCustomerID.getText() + orderManager.getCustomerID());
        txtOrderManagerName.setText(txtOrderManagerName.getText() + orderManager.getName().toUpperCase());
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        txtBookingDate.setText("Booking Date: " + format.format(new Date()));
        txtBookingID.setText("" + order.getBookingID());
        txtOrderType.setText("" + order.getFoodOrderType().toUpperCase());
        txtVenue.setText("" + order.getTableType().toUpperCase());
        txtGuestsCount.setText("" + order.getGuestsCount());
        txtTableType.setText("" + order.getTableType().toUpperCase());
        txtFoodItems.setText("" + order.getFoodItems().toUpperCase());
        txtVenueCost.setText("" + order.getVenueCost());
        txtFoodItemsCost.setText("" + order.getFoodItemsCost());
        txtTotalCost.setText("" + order.getFoodOrderCost());
    }

    Customer orderManager;


                           
    private void initComponents() {

        invoicePanel = new javax.swing.JPanel();
        lblHeadingtop = new javax.swing.JTextField();
        txtHeading = new javax.swing.JTextField();
        lblHeadingbottom = new javax.swing.JTextField();
        topSeparator = new javax.swing.JSeparator();
        bottomSeparator = new javax.swing.JSeparator();
        txtBookingDate = new javax.swing.JTextField();
        lblBookingID = new javax.swing.JLabel();
        lblOrderType = new javax.swing.JLabel();
        lblGuestsCount = new javax.swing.JLabel();
        lblItemsList = new javax.swing.JLabel();
        lblCost = new javax.swing.JLabel();
        lblVenue = new javax.swing.JLabel();
        txtBookingID = new javax.swing.JTextField();
        txtGuestsCount = new javax.swing.JTextField();
        txtTableType = new javax.swing.JTextField();
        txtFoodItems = new javax.swing.JTextField();
     
        txtVenueCost = new javax.swing.JTextField();
        txtFoodItemsCost = new javax.swing.JTextField();
        txtEquipmentCost = new javax.swing.JTextField();
        topCostSeparator = new javax.swing.JSeparator();
        bottomCostSeparator = new javax.swing.JSeparator();
        txtTotalCost = new javax.swing.JTextField();
        lblThankyou = new javax.swing.JLabel();
        btnSaveInvoice = new javax.swing.JButton();
        txtCustomerID = new javax.swing.JTextField();
        btnHome = new javax.swing.JButton();
        txtOrderManagerName = new javax.swing.JLabel();
        orderTypeScrollPane = new javax.swing.JScrollPane();
        txtOrderType = new javax.swing.JTextArea();
        venueScrollPane = new javax.swing.JScrollPane();
        txtVenue = new javax.swing.JTextArea();
        lblAuthorisedSignature = new javax.swing.JLabel();
        lblSignature = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        invoicePanel.setBackground(new java.awt.Color(0, 0, 0));
        invoicePanel.setForeground(new java.awt.Color(255, 255, 255));

        lblHeadingtop.setBackground(new java.awt.Color(0, 0, 0));
        lblHeadingtop.setFont(new java.awt.Font("Monospaced", 0, 14)); // NOI18N
        lblHeadingtop.setForeground(new java.awt.Color(255, 255, 255));
        
        lblHeadingtop.setBorder(null);
        lblHeadingtop.setMargin(new java.awt.Insets(0, 2, 0, 2));

        txtHeading.setBackground(new java.awt.Color(0, 0, 0));
        txtHeading.setFont(new java.awt.Font("Monospaced", 0, 15)); // NOI18N
        txtHeading.setForeground(new java.awt.Color(255, 255, 255));
        txtHeading.setText("ORDER BOOKING INVOICE");
        txtHeading.setBorder(null);

        lblHeadingbottom.setBackground(new java.awt.Color(0, 0, 0));
        lblHeadingbottom.setFont(new java.awt.Font("Monospaced", 0, 14)); // NOI18N
        lblHeadingbottom.setForeground(new java.awt.Color(255, 255, 255));
        
        lblHeadingbottom.setBorder(null);
        lblHeadingbottom.setMargin(new java.awt.Insets(0, 2, 0, 2));

        topSeparator.setPreferredSize(new java.awt.Dimension(70, 7));

        txtBookingDate.setBackground(new java.awt.Color(0, 0, 0));
        txtBookingDate.setFont(new java.awt.Font("Monospaced", 0, 12)); // NOI18N
        txtBookingDate.setForeground(new java.awt.Color(255, 255, 255));
        txtBookingDate.setText("BOOKING DATE : ");
        txtBookingDate.setBorder(null);
        txtBookingDate.setMargin(new java.awt.Insets(2, 2, 0, 2));

        lblBookingID.setFont(new java.awt.Font("Monospaced", 0, 12)); // NOI18N
        lblBookingID.setForeground(new java.awt.Color(255, 255, 255));
        lblBookingID.setText("BOOKING ID");

        lblOrderType.setBackground(new java.awt.Color(36, 37, 130));
        lblOrderType.setFont(new java.awt.Font("Monospaced", 0, 12)); // NOI18N
        lblOrderType.setForeground(new java.awt.Color(255, 255, 255));
        lblOrderType.setText("ORDER TYPE");

        lblGuestsCount.setFont(new java.awt.Font("Monospaced", 0, 12)); // NOI18N
        lblGuestsCount.setForeground(new java.awt.Color(255, 255, 255));
        lblGuestsCount.setText("GUESTS COUNT");

        lblItemsList.setBackground(new java.awt.Color(36, 37, 130));
        lblItemsList.setFont(new java.awt.Font("Monospaced", 0, 12)); // NOI18N
        lblItemsList.setForeground(new java.awt.Color(255, 255, 255));
        lblItemsList.setText("ITEMS");

        lblCost.setBackground(new java.awt.Color(36, 37, 130));
        lblCost.setFont(new java.awt.Font("Monospaced", 0, 12)); // NOI18N
        lblCost.setForeground(new java.awt.Color(255, 255, 255));
        lblCost.setText("COST");

        lblVenue.setBackground(new java.awt.Color(36, 37, 130));
        lblVenue.setFont(new java.awt.Font("Monospaced", 0, 14)); // NOI18N
        lblVenue.setForeground(new java.awt.Color(255, 255, 255));
        lblVenue.setText("VENUE");

        txtBookingID.setBackground(new java.awt.Color(0, 0, 0));
        txtBookingID.setFont(new java.awt.Font("Monospaced", 0, 12)); // NOI18N
        txtBookingID.setForeground(new java.awt.Color(255, 255, 255));
        txtBookingID.setBorder(null);

        txtGuestsCount.setBackground(new java.awt.Color(0, 0, 0));
        txtGuestsCount.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        txtGuestsCount.setForeground(new java.awt.Color(255, 255, 255));
        txtGuestsCount.setBorder(null);

        txtTableType.setBackground(new java.awt.Color(0, 0, 0));
        txtTableType.setFont(new java.awt.Font("Monospaced", 0, 12)); // NOI18N
        txtTableType.setForeground(new java.awt.Color(255, 255, 255));
        txtTableType.setBorder(null);

        txtFoodItems.setBackground(new java.awt.Color(0, 0, 0));
        txtFoodItems.setFont(new java.awt.Font("Monospaced", 0, 12)); // NOI18N
        txtFoodItems.setForeground(new java.awt.Color(255, 255, 255));
        txtFoodItems.setBorder(null);

       

        txtVenueCost.setBackground(new java.awt.Color(0, 0, 0));
        txtVenueCost.setFont(new java.awt.Font("Monospaced", 0, 12)); // NOI18N
        txtVenueCost.setForeground(new java.awt.Color(255, 255, 255));
        txtVenueCost.setBorder(null);

        txtFoodItemsCost.setBackground(new java.awt.Color(0, 0, 0));
        txtFoodItemsCost.setFont(new java.awt.Font("Monospaced", 0, 12)); // NOI18N
        txtFoodItemsCost.setForeground(new java.awt.Color(255, 255, 255));
        txtFoodItemsCost.setBorder(null);

        txtEquipmentCost.setBackground(new java.awt.Color(0, 0, 0));
        txtEquipmentCost.setFont(new java.awt.Font("Monospaced", 0, 12)); // NOI18N
        txtEquipmentCost.setForeground(new java.awt.Color(255, 255, 255));
        txtEquipmentCost.setBorder(null);

        txtTotalCost.setBackground(new java.awt.Color(0, 0, 0));
        txtTotalCost.setFont(new java.awt.Font("Monospaced", 0, 12)); // NOI18N
        txtTotalCost.setForeground(new java.awt.Color(255, 255, 255));
        txtTotalCost.setBorder(null);
        txtTotalCost.setMargin(new java.awt.Insets(0, 2, 0, 2));

        lblThankyou.setFont(new java.awt.Font("Monospaced", 0, 10)); // NOI18N
        lblThankyou.setForeground(new java.awt.Color(255, 255, 255));
        lblThankyou.setText("THANK YOU FOR YOUR TIME");

        btnSaveInvoice.setBackground(new java.awt.Color(255, 255, 255));
        btnSaveInvoice.setText("SAVE INVOICE");
        btnSaveInvoice.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveInvoiceActionPerformed(evt);
            }
        });

        txtCustomerID.setBackground(new java.awt.Color(0, 0, 0));
        txtCustomerID.setFont(new java.awt.Font("Monospaced", 0, 12)); // NOI18N
        txtCustomerID.setForeground(new java.awt.Color(255, 255, 255));
        txtCustomerID.setText("CUSTOMER ID : ");
        txtCustomerID.setBorder(null);

        btnHome.setBackground(new java.awt.Color(255, 255, 255));
        btnHome.setFont(new java.awt.Font("Trebuchet MS", 0, 11)); // NOI18N
        btnHome.setText("HOME");
        btnHome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHomeActionPerformed(evt);
            }
        });

        txtOrderManagerName.setFont(new java.awt.Font("Monospaced", 0, 12)); // NOI18N
        txtOrderManagerName.setForeground(new java.awt.Color(255, 255, 255));
        txtOrderManagerName.setText("CUSTOMER NAME : ");

        txtOrderType.setBackground(new java.awt.Color(0, 0, 0));
        txtOrderType.setColumns(20);
        txtOrderType.setFont(new java.awt.Font("Monospaced", 0, 12)); // NOI18N
        txtOrderType.setForeground(new java.awt.Color(255, 255, 255));
        txtOrderType.setLineWrap(true);
        txtOrderType.setRows(2);
        txtOrderType.setWrapStyleWord(true);
        txtOrderType.setAutoscrolls(false);
        txtOrderType.setBorder(null);
        orderTypeScrollPane.setViewportView(txtOrderType);

        txtVenue.setBackground(new java.awt.Color(0, 0, 0));
        txtVenue.setColumns(20);
        txtVenue.setForeground(new java.awt.Color(255, 255, 255));
        txtVenue.setLineWrap(true);
        txtVenue.setRows(2);
        txtVenue.setToolTipText("");
        txtVenue.setWrapStyleWord(true);
        txtVenue.setAutoscrolls(false);
        txtVenue.setBorder(null);
        venueScrollPane.setViewportView(txtVenue);

        lblAuthorisedSignature.setBackground(new java.awt.Color(36, 37, 130));
        lblAuthorisedSignature.setFont(new java.awt.Font("Monospaced", 0, 12)); // NOI18N
        lblAuthorisedSignature.setForeground(new java.awt.Color(255, 255, 255));
       

        javax.swing.GroupLayout invoicePanelLayout = new javax.swing.GroupLayout(invoicePanel);
        invoicePanel.setLayout(invoicePanelLayout);
        invoicePanelLayout.setHorizontalGroup(
            invoicePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, invoicePanelLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(txtBookingID, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(invoicePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(invoicePanelLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txtTableType, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(14, 14, 14))
                    .addGroup(invoicePanelLayout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addComponent(orderTypeScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(venueScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(51, 51, 51)
                        .addComponent(txtGuestsCount, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(53, 53, 53)
                        .addGroup(invoicePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            //.addComponent(txtEquipments, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtFoodItems, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)))
                .addGap(22, 22, 22)
                .addGroup(invoicePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(invoicePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(txtFoodItemsCost, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txtVenueCost, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(txtEquipmentCost, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23))
            .addGroup(invoicePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(invoicePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(invoicePanelLayout.createSequentialGroup()
                        .addComponent(topSeparator, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, invoicePanelLayout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(txtCustomerID, javax.swing.GroupLayout.PREFERRED_SIZE, 229, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txtBookingDate, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(invoicePanelLayout.createSequentialGroup()
                        .addComponent(bottomSeparator)
                        .addContainerGap())
                    .addGroup(invoicePanelLayout.createSequentialGroup()
                        .addComponent(bottomCostSeparator)
                        .addContainerGap())
                    .addGroup(invoicePanelLayout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(lblBookingID, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(44, 44, 44)
                        .addComponent(lblOrderType)
                        .addGap(95, 95, 95)
                        .addComponent(lblVenue)
                        .addGap(82, 82, 82)
                        .addComponent(lblGuestsCount)
                        .addGap(89, 89, 89)
                        .addComponent(lblItemsList)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblCost)
                        .addGap(52, 52, 52))))
            .addGroup(invoicePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(topCostSeparator)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, invoicePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(invoicePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, invoicePanelLayout.createSequentialGroup()
                        .addComponent(txtOrderManagerName, javax.swing.GroupLayout.PREFERRED_SIZE, 285, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnHome, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, invoicePanelLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(txtHeading, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(334, 334, 334))))
            .addGroup(invoicePanelLayout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(lblSignature, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnSaveInvoice)
                .addGap(27, 27, 27))
            .addGroup(invoicePanelLayout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addGroup(invoicePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblHeadingtop, javax.swing.GroupLayout.DEFAULT_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(lblHeadingbottom, javax.swing.GroupLayout.DEFAULT_SIZE, 797, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, invoicePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(invoicePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, invoicePanelLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(txtTotalCost, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(20, 20, 20))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, invoicePanelLayout.createSequentialGroup()
                        .addComponent(lblAuthorisedSignature, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblThankyou)
                        .addContainerGap())))
        );
        invoicePanelLayout.setVerticalGroup(
            invoicePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(invoicePanelLayout.createSequentialGroup()
                .addGap(9, 9, 9)
                .addGroup(invoicePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnHome)
                    .addComponent(txtOrderManagerName))
                .addGap(18, 18, 18)
                .addComponent(lblHeadingtop, javax.swing.GroupLayout.PREFERRED_SIZE, 11, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtHeading, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblHeadingbottom, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(invoicePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(invoicePanelLayout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addComponent(txtBookingDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, invoicePanelLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtCustomerID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(topSeparator, javax.swing.GroupLayout.PREFERRED_SIZE, 2, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(2, 2, 2)
                .addGroup(invoicePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblBookingID, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblOrderType)
                    .addComponent(lblGuestsCount)
                    .addComponent(lblItemsList)
                    .addComponent(lblCost)
                    .addComponent(lblVenue))
                .addGap(2, 2, 2)
                .addComponent(bottomSeparator, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(invoicePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtVenueCost, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtTableType, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(invoicePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(invoicePanelLayout.createSequentialGroup()
                        .addGroup(invoicePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(orderTypeScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(invoicePanelLayout.createSequentialGroup()
                                .addGroup(invoicePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(txtBookingID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtGuestsCount, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtFoodItems, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtFoodItemsCost, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(31, 31, 31)
                                .addGroup(invoicePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                  // .addComponent(txtEquipments, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtEquipmentCost, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(19, 19, 19)
                        .addComponent(topCostSeparator, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(3, 3, 3)
                        .addComponent(txtTotalCost, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(bottomCostSeparator, javax.swing.GroupLayout.PREFERRED_SIZE, 8, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 36, Short.MAX_VALUE)
                        .addGroup(invoicePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(invoicePanelLayout.createSequentialGroup()
                                .addComponent(btnSaveInvoice)
                                .addGap(11, 11, 11)
                                .addComponent(lblThankyou)
                                .addContainerGap())
                            .addGroup(invoicePanelLayout.createSequentialGroup()
                                .addComponent(lblSignature)
                                .addGap(0, 0, 0)
                                .addComponent(lblAuthorisedSignature)
                                .addGap(19, 19, 19))))
                    .addGroup(invoicePanelLayout.createSequentialGroup()
                        .addComponent(venueScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(invoicePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(invoicePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }                     

    private void btnHomeActionPerformed(java.awt.event.ActionEvent evt) {                                        
        this.setVisible(false);
        this.dispose();
        CustomerHomeGUI home = new CustomerHomeGUI(orderManager);
        home.setVisible(true);
    }                                       

    private void btnSaveInvoiceActionPerformed(java.awt.event.ActionEvent evt) {                                               
        PrinterJob job = PrinterJob.getPrinterJob();
        job.setJobName("Print Data");

        job.setPrintable(new Printable() {
            public int print(Graphics pg, PageFormat pf, int pageNum) {
                pf.setOrientation(PageFormat.LANDSCAPE);
                if (pageNum > 0) {
                    return Printable.NO_SUCH_PAGE;
                }
                Graphics2D g2 = (Graphics2D) pg;
                g2.translate(pf.getImageableX(), pf.getImageableY());
                g2.scale(0.75, 0.75);
                invoicePanel.paint(pg);
                return Printable.PAGE_EXISTS;
            }
        });
        boolean flag = job.printDialog();
        if (flag) {
            try {
                job.print();
            } catch (PrinterException ex) {
            }
        }
    }                                              

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new OrderInvoiceGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify                     
    private javax.swing.JSeparator bottomCostSeparator;
    private javax.swing.JSeparator bottomSeparator;
    private javax.swing.JButton btnHome;
    private javax.swing.JButton btnSaveInvoice;
    private javax.swing.JScrollPane orderTypeScrollPane;
    private javax.swing.JPanel invoicePanel;
    private javax.swing.JLabel lblAuthorisedSignature;
    private javax.swing.JLabel lblBookingID;
    private javax.swing.JLabel lblCost;
    private javax.swing.JLabel lblOrderType;
    private javax.swing.JLabel lblGuestsCount;
    private javax.swing.JTextField lblHeadingbottom;
    private javax.swing.JTextField lblHeadingtop;
    private javax.swing.JLabel lblItemsList;
    private javax.swing.JLabel lblSignature;
    private javax.swing.JLabel lblThankyou;
    private javax.swing.JLabel lblVenue;
    private javax.swing.JSeparator topCostSeparator;
    private javax.swing.JSeparator topSeparator;
    private javax.swing.JTextField txtBookingDate;
    private javax.swing.JTextField txtBookingID;
    private javax.swing.JTextField txtEquipmentCost;
    private javax.swing.JTextField txtCustomerID;
    private javax.swing.JLabel txtOrderManagerName;
    private javax.swing.JTextArea txtOrderType;
    private javax.swing.JTextField txtFoodItems;
    private javax.swing.JTextField txtFoodItemsCost;
    private javax.swing.JTextField txtGuestsCount;
    private javax.swing.JTextField txtHeading;
    private javax.swing.JTextField txtTotalCost;
    private javax.swing.JTextArea txtVenue;
    private javax.swing.JTextField txtVenueCost;
    private javax.swing.JTextField txtTableType;
    private javax.swing.JScrollPane venueScrollPane;
    // End of variables declaration                  
    
}
