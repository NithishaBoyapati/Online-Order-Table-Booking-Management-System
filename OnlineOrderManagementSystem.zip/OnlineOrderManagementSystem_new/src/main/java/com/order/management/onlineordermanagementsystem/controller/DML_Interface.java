package com.order.management.onlineordermanagementsystem.controller;

import com.order.management.onlineordermanagementsystem.Model.FoodItem;
import com.order.management.onlineordermanagementsystem.Model.FoodOrder;
import com.order.management.onlineordermanagementsystem.Model.Notification;
import com.order.management.onlineordermanagementsystem.Model.Customer;
import com.order.management.onlineordermanagementsystem.Model.Venue;

/**
 *
 * @author smacharla
 */
public interface DML_Interface {
    
    public abstract boolean  UpdateOrderManager(Customer orderManager);

    public abstract boolean InsertNotification(Notification notification);

    public abstract int InsertOrder(FoodOrder foodOrder);

    public abstract boolean UpdateOrder(FoodOrder foodOrder);

    public abstract int InsertFoodItem(FoodItem foodItem);

    public abstract boolean UpdateFoodItem(FoodItem foodItem);

    public abstract boolean DeleteFoodItem(int FoodItemID);

    public abstract int InsertVenue(Venue vn);

    public abstract boolean UpdateVenue(Venue vn);

    public abstract boolean DeleteVenue(int venueID);

    public abstract int InsertOrderManager(Customer em);

}
