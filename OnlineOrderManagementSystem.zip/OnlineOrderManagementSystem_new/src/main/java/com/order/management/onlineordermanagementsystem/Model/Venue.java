/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.order.management.onlineordermanagementsystem.Model;

/**
 *
 * @author smacharla
 */
public class Venue {

    private int venueID;
    private String tableType;
    private String venuePlace;
    private double venueCost;
    private String venueImagePath;

    public Venue(int venueID, String tableType, String venuePlace, double venueCost, String venueImagePath) {
        this.venueID = venueID;
        this.tableType = tableType;
        this.venuePlace = venuePlace;
        this.venueCost = venueCost;
        this.venueImagePath=venueImagePath;
    }
    public Venue( String tableType, String venuePlace, double venueCost, String venueImagePath) {
       
        this.tableType = tableType;
        this.venuePlace = venuePlace;
        this.venueCost = venueCost;
        this.venueImagePath=venueImagePath;
    }

    public int getVenueID() {
        return venueID;
    }

    public void setVenueID(int venueID) {
        this.venueID = venueID;
     }

    public String getTableType() {
        return tableType;
    }

    public void setTableType(String tableType) {
        this.tableType = tableType;
    }

    public String getVenuePlace() {
        return venuePlace;
    }

    public void setVenuePlace(String venuePlace) {
        this.venuePlace = venuePlace;
    }

    public double getVenueCost() {
        return venueCost;
    }

    public void setVenueCost(double venueCost) {
        this.venueCost = venueCost;
    }

      public String getVenueImagePath() {
        return venueImagePath;
    }

    public void setVenueImagePath(String venueImagePath) {
        this.venueImagePath = venueImagePath;
    }
}
