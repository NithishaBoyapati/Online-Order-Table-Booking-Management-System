/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.order.management.onlineordermanagementsystem.Model;

/**
 *
 * @author smacharla
 */
public class FoodItem {

    private int foodItemId;
    private String foodItemName;
    private double foodItemCost;
    private String foodImagePath;

    public FoodItem(int foodItemId, String foodItemName, double foodItemCost, String foodImagePath) {
        this.foodItemId = foodItemId;
        this.foodItemName = foodItemName;
        this.foodItemCost = foodItemCost;
        this.foodImagePath = foodImagePath;
    }

    public FoodItem(String foodItemName, double foodItemCost, String foodImagePath) {

        this.foodItemName = foodItemName;
        this.foodItemCost = foodItemCost;
        this.foodImagePath = foodImagePath;
    }

    public int getFoodItemId() {
        return foodItemId;
    }

    public void setFoodItemId(int foodItemId) {
        this.foodItemId = foodItemId;
    }

    public String getFoodItemName() {
        return foodItemName;
    }

    public void setFoodItemName(String foodItemName) {
        this.foodItemName = foodItemName;
    }

    public double getFoodItemCost() {
        return foodItemCost;
    }

    public void setFoodItemCost(double foodItemCost) {
        this.foodItemCost = foodItemCost;
    }

    public String getFoodImagePath() {
        return foodImagePath;
    }

    public void setFoodImagePath(String foodImagePath) {
        this.foodImagePath = foodImagePath;
    }
}
