/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.order.management.onlineordermanagementsystem.View;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import javax.swing.JLabel;

/**
 *
 * @author smacharla
 */
public class OrderHomeGUI extends javax.swing.JFrame {

    
    GridBagLayout layout = new GridBagLayout();
    CustomerRegisterGUI register;
    CustomerLoginGUI login;
    AdminLoginGUI admin;

    public OrderHomeGUI() {
        super("Home");
        initComponents();
        backgroundbuttons.setHorizontalTextPosition(backgroundbuttons.CENTER);
        backgroundbuttons.setVerticalTextPosition(backgroundbuttons.CENTER);

        
        btnOrderManagerRegister.setVisible(true);
        btnOrderManagerLogin.setVisible(true);
        btnAdminLogin.setVisible(true);

        setSize(740, 550);  //set size of frame
        setResizable(false); // frame can't be resized
        setLocationRelativeTo(null); // set frame at center of screen
        setDefaultCloseOperation(EXIT_ON_CLOSE);  //default exist when prexx X icon

     
        register = new CustomerRegisterGUI();
        login = new CustomerLoginGUI();
        admin = new AdminLoginGUI();
        DynamicPanels.setLayout(layout);

        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 0;
        c.fill = GridBagConstraints.HORIZONTAL;
        
        c.anchor = GridBagConstraints.NORTHWEST;
        c.weightx = 2;
        c.weighty = 1;

        
        c.gridx = 0;
        c.gridy = 0;
        c.fill = GridBagConstraints.HORIZONTAL;
        btnOrderManagerRegister.setPreferredSize(new Dimension(1600, 1600));
        c.anchor = GridBagConstraints.NORTHWEST;
        c.weightx = 2;
        c.weighty = 1;
        DynamicPanels.add(register, c);

        c.gridx = 0;
        c.gridy = 0;
        c.anchor = GridBagConstraints.NORTHEAST;
        c.weightx = 2;
        c.weighty = 1;
        DynamicPanels.add(login, c);

        c.gridx = 0;
        c.gridy = 0;
        c.weightx = 3;
        DynamicPanels.add(admin, c);

        
        register.setVisible(false);
        login.setVisible(true);
        admin.setVisible(false);
    }

    @SuppressWarnings("unchecked")
                            
    private void initComponents() {

        jTextField2 = new javax.swing.JTextField();
        HomeMainPanel = new javax.swing.JPanel();
        DynamicPanels = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        backgroundbuttons = new javax.swing.JLabel();
        buttonsPanel = new javax.swing.JPanel();
       
        btnOrderManagerRegister = new javax.swing.JButton();
        btnOrderManagerLogin = new javax.swing.JButton();
        btnAdminLogin = new javax.swing.JButton();
        background = new javax.swing.JLabel();

        jTextField2.setText("jTextField2");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(153, 51, 0));

        HomeMainPanel.setBackground(new java.awt.Color(185, 52, 99));
        HomeMainPanel.setForeground(new java.awt.Color(36, 37, 130));

        DynamicPanels.setBackground(new java.awt.Color(204, 0, 102));
        DynamicPanels.setForeground(new java.awt.Color(36, 37, 130));
        DynamicPanels.setDoubleBuffered(false);

        javax.swing.GroupLayout DynamicPanelsLayout = new javax.swing.GroupLayout(DynamicPanels);
        DynamicPanels.setLayout(DynamicPanelsLayout);
        DynamicPanelsLayout.setHorizontalGroup(
                DynamicPanelsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGap(0, 0, Short.MAX_VALUE)
        );
        DynamicPanelsLayout.setVerticalGroup(
                DynamicPanelsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGap(0, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGap(0, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout HomeMainPanelLayout = new javax.swing.GroupLayout(HomeMainPanel);
        HomeMainPanel.setLayout(HomeMainPanelLayout);
        HomeMainPanelLayout.setHorizontalGroup(
                HomeMainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(HomeMainPanelLayout.createSequentialGroup()
                                .addComponent(DynamicPanels, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        HomeMainPanelLayout.setVerticalGroup(
                HomeMainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(HomeMainPanelLayout.createSequentialGroup()
                                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(DynamicPanels, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(360, Short.MAX_VALUE))
        );

        backgroundbuttons.setFont(new java.awt.Font("AR DECODE", 1, 28)); // NOI18N
        backgroundbuttons.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
 
        backgroundbuttons.setText("ONLINE ORDER MANAGEMENT SYSTEM");
        backgroundbuttons.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        buttonsPanel.setLayout(null);



        btnOrderManagerRegister.setBackground(new java.awt.Color(0, 0, 0));
        btnOrderManagerRegister.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnOrderManagerRegister.setForeground(new java.awt.Color(255, 255, 255));
        btnOrderManagerRegister.setText("REGISTER");
        btnOrderManagerRegister.setPreferredSize(new java.awt.Dimension(64, 23));
        btnOrderManagerRegister.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOrderManagerRegisterActionPerformed(evt);
            }
        });
        buttonsPanel.add(btnOrderManagerRegister);
        btnOrderManagerRegister.setBounds(300, 10, 150, 23);

        btnOrderManagerLogin.setBackground(new java.awt.Color(0, 0, 0));
        btnOrderManagerLogin.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnOrderManagerLogin.setForeground(new java.awt.Color(255, 255, 255));
        btnOrderManagerLogin.setText("LOGIN");
        btnOrderManagerLogin.setPreferredSize(new java.awt.Dimension(64, 23));
        btnOrderManagerLogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOrderManagerLoginActionPerformed(evt);
            }
        });
        buttonsPanel.add(btnOrderManagerLogin);
        //btnOrderManagerLogin.setBounds(393, 10, 140, 23);
        btnOrderManagerLogin.setBounds(50, 10, 140, 23);
        btnAdminLogin.setBackground(new java.awt.Color(0, 0, 0));
        btnAdminLogin.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnAdminLogin.setForeground(new java.awt.Color(255, 255, 255));
        btnAdminLogin.setText("ADMIN");
        btnAdminLogin.setPreferredSize(new java.awt.Dimension(64, 23));
        btnAdminLogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAdminLoginActionPerformed(evt);
            }
        });
        buttonsPanel.add(btnAdminLogin);
        btnAdminLogin.setBounds(550, 10, 148, 23);

        background.setBackground(new java.awt.Color(204, 51, 0));

        buttonsPanel.add(background);
        background.setBounds(0, 0, 770, 40);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(buttonsPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 756, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(backgroundbuttons, javax.swing.GroupLayout.PREFERRED_SIZE, 764, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(HomeMainPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addComponent(backgroundbuttons, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(buttonsPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addComponent(HomeMainPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }

    private void btnAboutUsActionPerformed(java.awt.event.ActionEvent evt) {
        
        register.setVisible(false);
        login.setVisible(false);
        admin.setVisible(false);
    }

    private void btnAdminLoginActionPerformed(java.awt.event.ActionEvent evt) {
      
        register.setVisible(false);
        login.setVisible(false);
        admin.setVisible(true);
    }

    private void btnOrderManagerRegisterActionPerformed(java.awt.event.ActionEvent evt) {
       
        register.setVisible(true);
        login.setVisible(false);
        admin.setVisible(false);
    }

    private void btnOrderManagerLoginActionPerformed(java.awt.event.ActionEvent evt) {
       
        register.setVisible(false);
        login.setVisible(true);
        admin.setVisible(false);
    }

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new OrderHomeGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify                     
    private javax.swing.JPanel DynamicPanels;
    private javax.swing.JPanel HomeMainPanel;
    private javax.swing.JLabel backgroundbuttons;
    private javax.swing.JLabel background;
    
    private javax.swing.JButton btnAdminLogin;
    private javax.swing.JButton btnOrderManagerLogin;
    private javax.swing.JButton btnOrderManagerRegister;
    private javax.swing.JPanel buttonsPanel;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField jTextField2;
    // End of variables declaration                   

}
