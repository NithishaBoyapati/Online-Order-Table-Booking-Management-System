/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.order.management.onlineordermanagementsystem.Model;

import java.sql.Date;
import java.util.ArrayList;

/**
 *
 * @author smacharla
 */

public class FoodOrder {

    private int customerID;
    private int orderID;
    private Date orderDate;
    private String orderTime;
    private String orderType;
    private String tableType;
    private String venueType;
    private String foodItems;
    private int guestsCount;
    private double VenueCost;
    private double FoodItemsCost;
    private double orderCost;
    private String paymentStatus;

    public FoodOrder(int customerID, String orderType, String tableType, String venueType, Date orderDate,String orderTime, String foodItems, int guestsCount, double venueCost, double foodItemsCost, double orderCost, String paymentStatus) {
        this.customerID = customerID;
        this.orderType = orderType;
        this.tableType = tableType;
        this.venueType = venueType;
        this.orderDate = orderDate;
        this.orderTime = orderTime;
        this.foodItems = foodItems;
        this.guestsCount = guestsCount;
        this.VenueCost = venueCost;
        this.FoodItemsCost = foodItemsCost;
        this.orderCost = orderCost;
        this.paymentStatus = paymentStatus;
    }

    public FoodOrder(int orderID, int customerID, String orderType, String tableType, String venueType, Date orderDate,String orderTime, String foodItems, int guestsCount, double venueCost, double foodItemsCost, double orderCost, String paymentStatus) {
        this.orderID = orderID;
        this.customerID = customerID;
        this.orderType = orderType;
        this.tableType = tableType;
        this.venueType = venueType;
        this.orderDate = orderDate;
        this.foodItems = foodItems;
        this.guestsCount = guestsCount;
        this.VenueCost = venueCost;
        this.FoodItemsCost = foodItemsCost;
        this.orderCost = orderCost;
        this.paymentStatus = paymentStatus;
        this.orderTime = orderTime;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    public int getFoodCustomerID() {
        return customerID;
    }

    public void setFoodCustomerID(int customerID) {
        this.customerID = customerID;
    }

    public int getBookingID() {
        return orderID;
    }

    public void setBookingID(int orderID) {
        this.orderID = orderID;
    }

    public Date getFoodOrderDate() {
        return orderDate;
    }

    public void setFoodOrderDate(Date orderDate) {
        this.orderDate = orderDate;
    }

    public String getOrderTime(){
        return orderTime;
    }
    
    public void setOrderTime(String orderTime){
        this.orderTime = orderTime;
    }
    
    
    public String getFoodOrderType() {
        return orderType;
    }

    public void setFoodOrderType(String orderType) {
        this.orderType = orderType;
    }

    public String getTableType() {
        return tableType;
    }

    public void setTableType(String tableType) {
        this.tableType = tableType;
    }

    public String getVenueType() {
        return venueType;
    }

    public void setVenueType(String venueType) {
        this.venueType = venueType;
    }

    public String getFoodItems() {
        return foodItems;
    }

    public void setFoodItems(String foodItems) {
        this.foodItems = foodItems;
    }

    public double getFoodOrderCost() {
        return orderCost;
    }

    public void setFoodOrderCost(double orderCost) {
        this.orderCost = orderCost;
    }

    public int getGuestsCount() {
        return guestsCount;
    }

    public void setGuestsCount(int guestsCount) {
        this.guestsCount = guestsCount;
    }

    public double getVenueCost() {
        return VenueCost;
    }

    public void setVenueCost(double VenueCost) {
        this.VenueCost = VenueCost;
    }

    public double getFoodItemsCost() {
        return FoodItemsCost;
    }

    public void setFoodItemsCost(double FoodItemsCost) {
        this.FoodItemsCost = FoodItemsCost;
    }

}
