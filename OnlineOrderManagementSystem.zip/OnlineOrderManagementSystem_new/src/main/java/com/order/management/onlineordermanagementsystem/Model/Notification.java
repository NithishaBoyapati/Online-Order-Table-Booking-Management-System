/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.order.management.onlineordermanagementsystem.Model;

import java.sql.Date;

/**
 *
 * @author smacharla
 */
public class Notification {
    
     private int customerID;
    private String message;
    private Date sentDate;

    public Notification(int customerID, String message, Date sentDate) {
        this.customerID = customerID;
        this.message = message;
        this.sentDate = sentDate;

    }

    public int getCustomerID() {
        return customerID;
    }

    public void setCustomerID(int customerID) {
        this.customerID = customerID;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Date getSentDate() {
        return sentDate;
    }

    public void setSentDate(Date sentDate) {
        this.sentDate = sentDate;
    }

    
}
