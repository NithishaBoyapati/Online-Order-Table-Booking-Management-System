/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.order.management.onlineordermanagementsystem.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author smacharla
 */
public class DBConnection {

    /**
     * Main database constants for connection - for ease of access and change
     */
    public static final String USER_NAME = "root";
    public static final String PASSWORD = "root";
    public static final String URL = "jdbc:mysql://localhost:3306/test?autoReconnect=true&useSSL=false";
    public static final String DB_NAME = "ordermanagementdb";
    public static final String DRIVER = "com.mysql.jdbc.Driver";
    
    private Statement st;
    private Connection conn = null;

    protected DBConnection() {
        try {
            //load mysql driver
            Class.forName(DRIVER);
            //connect to mysql database with username and password
            conn = DriverManager.getConnection(URL, USER_NAME, PASSWORD);
            st = conn.createStatement();
            createDataBase(); // create database
        } catch (ClassNotFoundException ex) {
            JOptionPane.showMessageDialog(null, "Driver Not Found"); // show error if ar not added to project
            System.exit(0);
        } catch (SQLException ex) { // if database exist
            ex.printStackTrace();
        }
    }

    public Connection getConnection() {
        return conn;
    }
    
    private void createDataBase() {
        try {
            //if no database named inventor then create it
            st.execute("CREATE DATABASE IF NOT EXISTS ordermanagerdb;");

            //create tables
            st.execute("CREATE TABLE IF NOT EXISTS  ORDERMANAGEMENTDB.admin (AdminID varchar(100) NOT NULL, Password varchar(100) DEFAULT NULL,PRIMARY KEY (AdminID),UNIQUE KEY Admincol_UNIQUE (Password)); ");

            st.execute("CREATE TABLE IF NOT EXISTS  ORDERMANAGEMENTDB.ordermanager ( CustomerID int(11) NOT NULL AUTO_INCREMENT,Name varchar(100) NOT NULL,Mobile varchar(50) NOT NULL,Email varchar(100) NOT NULL,Address varchar(1000) NOT NULL,Password varchar(100) NOT NULL,Gender varchar(100) NOT NULL,Subscribe int(11) NOT NULL,PRIMARY KEY (CustomerID))AUTO_INCREMENT=1000;");
            st.execute("CREATE TABLE IF NOT EXISTS  ORDERMANAGEMENTDB.gender (Name varchar(100) NOT NULL,PRIMARY KEY (Name)); ");
            st.execute("CREATE TABLE IF NOT EXISTS  ORDERMANAGEMENTDB.venuetype (Name varchar(100) NOT NULL,PRIMARY KEY (Name)); ");
            st.execute("CREATE TABLE IF NOT EXISTS  ORDERMANAGEMENTDB.venue (VenueID int(11) NOT NULL AUTO_INCREMENT,Name varchar(500) NOT NULL,Place varchar(500) NOT NULL,Cost double NOT NULL,ImagePath varchar(1000) DEFAULT NULL,PRIMARY KEY (VenueID)); ");
            st.execute("CREATE TABLE IF NOT EXISTS  ORDERMANAGEMENTDB.fooditems (FoodItemID int(11) NOT NULL AUTO_INCREMENT,FoodItemName varchar(500) NOT NULL,FoodItemCost double NOT NULL,FoodItemImagePath varchar(1000) NOT NULL,PRIMARY KEY (FoodItemID))AUTO_INCREMENT=1000;");
            st.execute("CREATE TABLE IF NOT EXISTS  ORDERMANAGEMENTDB.Ordertype (Name varchar(100) NOT NULL,PRIMARY KEY (Name)); ");
            st.execute("CREATE TABLE IF NOT EXISTS  ORDERMANAGEMENTDB.ORDER (BookingID int(11) NOT NULL AUTO_INCREMENT,CUSTOMERID int(11) NOT NULL,OrderType varchar(100) NOT NULL,TableType varchar(100) NOT NULL,VenueType varchar(100) NOT NULL,OrderDate date NOT NULL,FoodItems varchar(100) NOT NULL, NoOfGuests int(11) NOT NULL,VenueCost double NOT NULL,FoodItemsCost double NOT NULL,OrderCost double NOT NULL,PaymentStatus varchar(100) NOT NULL,PRIMARY KEY (BookingID))AUTO_INCREMENT=548919;");
            st.execute("CREATE TABLE IF NOT EXISTS  ORDERMANAGEMENTDB.notifications (CustomerID int(11) NOT NULL,Message varchar(10000) NOT NULL,SentDate date NOT NULL); ");

            //Insert Admin creds
            st.execute("INSERT INTO ORDERMANAGEMENTDB.admin (AdminID,Password)  values('admin','admin')");
            st.execute("INSERT INTO ORDERMANAGEMENTDB.gender VALUES ('Female'),('Male');");
            st.execute("INSERT INTO ORDERMANAGEMENTDB.venuetype VALUES ('Indoor'),('Outdoor');");
            st.execute("INSERT INTO ORDERMANAGEMENTDB.Ordertype VALUES ('Vegetarian'),('Non-Vegetarian'),('Both');");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    
}
