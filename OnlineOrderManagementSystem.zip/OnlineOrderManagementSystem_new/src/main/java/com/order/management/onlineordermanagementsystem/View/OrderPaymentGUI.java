/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.order.management.onlineordermanagementsystem.View;

import com.order.management.onlineordermanagementsystem.Model.FoodOrder;
import com.order.management.onlineordermanagementsystem.Model.Customer;
import com.order.management.onlineordermanagementsystem.Model.Venue;
import com.order.management.onlineordermanagementsystem.controller.DatabaseQueries;
import java.awt.Image;
import javax.swing.ImageIcon;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import javax.swing.JOptionPane;

/**
 *
 * @author smacharla
 */
public class OrderPaymentGUI extends javax.swing.JFrame {
    
    

    public OrderPaymentGUI() {
        initComponents();
    }

    public OrderPaymentGUI(Customer orderManager, Venue venue, FoodOrder order) {
        super("OrderPayment");
        initComponents();
        this.order = order;
        this.orderManager = orderManager;
        setResizable(false); // frame can't be resized
        setLocationRelativeTo(null); // set frame at center of screen
        setDefaultCloseOperation(EXIT_ON_CLOSE);  //default exist when prexx X icon
        this.order = order;
        lblWelcome.setText("Welcome " + orderManager.getName());
        txtBookingID.setText("" + order.getBookingID());
        txtTotalCost.setText("" + order.getFoodOrderCost());
        setVenueImage(venue);
    }

    private void setVenueImage(Venue venue) {
        String venuePath = venue.getVenueImagePath();
        if (!venuePath.trim().isEmpty()) {
            lblVenueImage.setIcon(resizeImage(venuePath));
        } else {
            lblVenueImage.setIcon(null);
        }
    }

    private ImageIcon resizeImage(String imagePath) {
        ImageIcon venueImage = new ImageIcon(imagePath);
        Image img = venueImage.getImage().getScaledInstance(lblVenueImage.getWidth(), lblVenueImage.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon venueFixedImage = new ImageIcon(img);
        return venueFixedImage;
    }

    @SuppressWarnings("unchecked")
                            
    private void initComponents() {

        paymentPanel = new javax.swing.JPanel();
        lblHeading = new javax.swing.JLabel();
        lblCardNo = new javax.swing.JLabel();
        lblCVVNo = new javax.swing.JLabel();
        lblNameonCard = new javax.swing.JLabel();
        lblExpirationDate = new javax.swing.JLabel();
        btnPay = new javax.swing.JButton();
        btnClear = new javax.swing.JButton();
        lblBookingID = new javax.swing.JLabel();
        txtBookingID = new javax.swing.JTextField();
        txtTotalCost = new javax.swing.JTextField();
        lblTotalCost = new javax.swing.JLabel();
        txtCardNo = new javax.swing.JTextField();
        txtCVVNo = new javax.swing.JTextField();
        txtNameonCard = new javax.swing.JTextField();
        lblVenueImage = new javax.swing.JLabel();
        lblWelcome = new javax.swing.JLabel();
        monthExpiration = new com.toedter.calendar.JMonthChooser();
        yearExpiration = new com.toedter.calendar.JYearChooser();
        btnBack = new javax.swing.JButton();
        background = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        paymentPanel.setBackground(new java.awt.Color(0, 0, 0));
        paymentPanel.setForeground(new java.awt.Color(255, 255, 255));
        paymentPanel.setLayout(null);

        lblHeading.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        lblHeading.setForeground(new java.awt.Color(255, 255, 255));
        lblHeading.setText("Pay for Order");
        paymentPanel.add(lblHeading);
        lblHeading.setBounds(309, 12, 93, 17);

        lblCardNo.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblCardNo.setForeground(new java.awt.Color(255, 255, 255));
        lblCardNo.setText("Card No");
        paymentPanel.add(lblCardNo);
        lblCardNo.setBounds(36, 112, 48, 15);

        lblCVVNo.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblCVVNo.setForeground(new java.awt.Color(255, 255, 255));
        lblCVVNo.setText("CVV No");
        paymentPanel.add(lblCVVNo);
        lblCVVNo.setBounds(36, 150, 44, 15);

        lblNameonCard.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblNameonCard.setForeground(new java.awt.Color(255, 255, 255));
        lblNameonCard.setText("Name on Card");
        paymentPanel.add(lblNameonCard);
        lblNameonCard.setBounds(370, 72, 85, 15);

        lblExpirationDate.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblExpirationDate.setForeground(new java.awt.Color(255, 255, 255));
        lblExpirationDate.setText("Expiration Date ");
        paymentPanel.add(lblExpirationDate);
        lblExpirationDate.setBounds(370, 112, 99, 24);

        
        btnPay.setBackground(new java.awt.Color(0, 0, 0));
        btnPay.setForeground(new java.awt.Color(255, 255, 255));
        btnPay.setText("PAY");
        btnPay.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPayActionPerformed(evt);
            }
        });
        paymentPanel.add(btnPay);
        btnPay.setBounds(450, 250, 92, 23);

     
        btnClear.setBackground(new java.awt.Color(0, 0, 0));
        btnClear.setForeground(new java.awt.Color(255, 255, 255));
        btnClear.setText("CLEAR");
        btnClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearActionPerformed(evt);
            }
        });
        paymentPanel.add(btnClear);
        btnClear.setBounds(570, 250, 89, 23);

        lblBookingID.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblBookingID.setForeground(new java.awt.Color(255, 255, 255));
        lblBookingID.setText("Booking ID");
        paymentPanel.add(lblBookingID);
        lblBookingID.setBounds(36, 74, 68, 15);

        txtBookingID.setEditable(false);
        txtBookingID.setBackground(new java.awt.Color(255, 255, 255));
        paymentPanel.add(txtBookingID);
        txtBookingID.setBounds(153, 72, 173, 20);

        txtTotalCost.setEditable(false);
        txtTotalCost.setBackground(new java.awt.Color(255, 255, 255));
        paymentPanel.add(txtTotalCost);
        txtTotalCost.setBounds(524, 200, 117, 20);

        lblTotalCost.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        lblTotalCost.setForeground(new java.awt.Color(255, 255, 255));
        lblTotalCost.setText("Total Cost");
        paymentPanel.add(lblTotalCost);
        lblTotalCost.setBounds(439, 200, 56, 15);
        paymentPanel.add(txtCardNo);
        txtCardNo.setBounds(153, 110, 173, 20);
        paymentPanel.add(txtCVVNo);
        txtCVVNo.setBounds(153, 148, 173, 20);
        paymentPanel.add(txtNameonCard);
        txtNameonCard.setBounds(500, 72, 173, 20);

        lblVenueImage.setBackground(new java.awt.Color(255, 255, 255));
        lblVenueImage.setOpaque(true);
        paymentPanel.add(lblVenueImage);
        lblVenueImage.setBounds(100, 180, 312, 176);

        lblWelcome.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblWelcome.setForeground(new java.awt.Color(255, 255, 255));
        lblWelcome.setText("Welcome");
        paymentPanel.add(lblWelcome);
        lblWelcome.setBounds(35, 14, 289, 15);
        paymentPanel.add(monthExpiration);
        monthExpiration.setBounds(500, 112, 106, 20);//153
        paymentPanel.add(yearExpiration);
        yearExpiration.setBounds(616, 112, 57, 20);

        btnBack.setBackground(new java.awt.Color(0, 0, 0));
        btnBack.setForeground(new java.awt.Color(255, 255, 255));
        btnBack.setText("BACK");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });
        paymentPanel.add(btnBack);
        btnBack.setBounds(630, 330, 83, 23);

        paymentPanel.add(background);
        background.setBounds(0, 0, 760, 390);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(paymentPanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 761, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(paymentPanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 389, Short.MAX_VALUE)
        );

        pack();
    }
    private void btnPayActionPerformed(java.awt.event.ActionEvent evt) {                                       
        String cardNo = txtCardNo.getText().trim();
        String cvvNo = txtCVVNo.getText().trim();
        String name = txtNameonCard.getText().trim();
        int expirationMonth = monthExpiration.getMonth();
        int expirationYear = yearExpiration.getYear();
        String validationMessage = "";
        if (cardNo.isEmpty()) {
            validationMessage += "Card Number is empty";
        }
        if (cvvNo.isEmpty()) {
            validationMessage += "\nCVV Number is empty";
        }
        if (name.isEmpty()) {
            validationMessage += "\nName on Card is empty";
        }
        if (validationMessage != "") {
            JOptionPane.showMessageDialog(null, validationMessage); // show message
            return; // end method
        }
        if (!cardNo.matches("\\d+")) {
            JOptionPane.showMessageDialog(null, "Card Number is not valid"); // show message
            return; // end method
        }
        if (!cvvNo.matches("\\d+")) {
            JOptionPane.showMessageDialog(null, "CVV Number is not valid"); // show message
            return; // end method
        }
        if (cvvNo.length() != 3) {
            JOptionPane.showMessageDialog(null, "CVV Number should be 3 digits"); // show message
            return; // end method
        }

        order.setPaymentStatus("Completed");
        DatabaseQueries.DML().UpdateOrder(order);

        //Generate receipt
        OrderInvoiceGUI invoiceGUI = new OrderInvoiceGUI(orderManager, order);
        this.setVisible(false);
        invoiceGUI.setVisible(true);
    }                                      

    private void btnClearActionPerformed(java.awt.event.ActionEvent evt) {                                         
        txtCardNo.setText("");
        txtCVVNo.setText("");
        txtNameonCard.setText("");
    }                                        

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {                                        
        this.setVisible(false);
        this.dispose();
        CustomerHomeGUI home = new CustomerHomeGUI(orderManager);
        home.setVisible(true);
    }                                       

    Customer orderManager;
    FoodOrder order;

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new OrderPaymentGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify                     
    private javax.swing.JLabel background;
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnClear;
    private javax.swing.JButton btnPay;
    private javax.swing.JLabel lblBookingID;
    private javax.swing.JLabel lblCVVNo;
    private javax.swing.JLabel lblCardNo;
    private javax.swing.JLabel lblExpirationDate;
    private javax.swing.JLabel lblHeading;
    private javax.swing.JLabel lblNameonCard;
    private javax.swing.JLabel lblTotalCost;
    private javax.swing.JLabel lblVenueImage;
    private javax.swing.JLabel lblWelcome;
    private com.toedter.calendar.JMonthChooser monthExpiration;
    private javax.swing.JPanel paymentPanel;
    private javax.swing.JTextField txtBookingID;
    private javax.swing.JTextField txtCVVNo;
    private javax.swing.JTextField txtCardNo;
    private javax.swing.JTextField txtNameonCard;
    private javax.swing.JTextField txtTotalCost;
    private com.toedter.calendar.JYearChooser yearExpiration;
    // End of variables declaration                   
    
}
