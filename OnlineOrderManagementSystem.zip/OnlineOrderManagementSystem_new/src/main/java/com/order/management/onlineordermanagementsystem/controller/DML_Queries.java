package com.order.management.onlineordermanagementsystem.controller;

/**
 *
 * @author smacharla
 */
import com.order.management.onlineordermanagementsystem.Model.FoodItem;
import com.order.management.onlineordermanagementsystem.Model.FoodOrder;
import com.order.management.onlineordermanagementsystem.Model.Notification;
import com.order.management.onlineordermanagementsystem.Model.Customer;
import com.order.management.onlineordermanagementsystem.Model.Venue;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class DML_Queries extends DatabaseQueries implements DML_Interface {

    protected PreparedStatement pst = null;
    protected Statement st = null;
    protected ResultSet rs = null;

    private static DML_Queries inst;

    public static DML_Queries getInst() {
        if (inst == null) {
            inst = new DML_Queries();
        }
        return inst;
    }

    @Override
    public int InsertOrderManager(Customer em) {
        int id = 0;
        try {
            String query = "insert into ORDERMANAGEMENTDB.ordermanager (Name,Mobile,Email,Address,Password,Gender,Subscribe) values(?,?,?,?,?,?,?);";
            pst = getConnection().prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
            pst.setString(1, em.getName());
            pst.setString(2, em.getMobile());
            pst.setString(3, em.getEmail());
            pst.setString(4, em.getAddress());
            pst.setString(5, em.getPassword());
            pst.setString(6, em.getGender());
            pst.setInt(7, em.getSubscribe());
            pst.execute();
            rs = pst.getGeneratedKeys();
            if (rs.next()) {
                id = rs.getInt(1);
                System.out.println("got student id" + id);
            }
            return id;

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Insert OrderManager failed");
        }
        return id;
    }

    @Override
    public boolean InsertNotification(Notification notification) {
        try {
            String query = "insert into ordermanagementdb.Notifications (CustomerID, Message, SentDate) values(?,?,?)";
            pst = getConnection().prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
            pst.setInt(1, notification.getCustomerID());
            pst.setString(2, notification.getMessage());
            pst.setDate(3, notification.getSentDate());
            pst.execute();
            return true;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Insert Notification failed");
        }
        return false;
    }

    @Override
    public int InsertVenue(Venue vn) {
        int id = 0;
        try {
            String query = "insert into ORDERMANAGEMENTDB.VENUE (Name,Place,Cost,ImagePath) values(?,?,?,?);";
            pst = getConnection().prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
            pst.setString(1, vn.getTableType());
            pst.setString(2, vn.getVenuePlace());
            pst.setDouble(3, vn.getVenueCost());
            pst.setString(4, vn.getVenueImagePath());

            pst.execute();
            rs = pst.getGeneratedKeys();
            if (rs.next()) {
                id = rs.getInt(1);
                System.out.println("VENUE ID: " + id);
            }
            return id;

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Insert Venue failed");
        }
        return id;
    }

    @Override
    public boolean UpdateVenue(Venue vn) {

        try {
            String query = "UPDATE ORDERMANAGEMENTDB.VENUE SET "
                    + "Name = ?,"
                    + "Place = ?,"
                    + "Cost = ?,"
                    + "ImagePath=?"
                    + " WHERE VenueID = ? ";
            pst = getConnection().prepareStatement(query);
            pst.setString(1, vn.getTableType());
            pst.setString(2, vn.getVenuePlace());
            pst.setDouble(3, vn.getVenueCost());
            pst.setString(4, vn.getVenueImagePath());
            pst.setInt(5, vn.getVenueID());
            pst.executeUpdate();
            return true;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Update Venue failed");
        }
        return false;
    }

    @Override
    public boolean DeleteVenue(int venueID) {
        try {
            String query = "DELETE FROM ORDERMANAGEMENTDB.VENUE WHERE venueID=" + venueID;
            st = getConnection().createStatement();
            st.executeUpdate(query);
            return true;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "No Such Venue exist");
        }
        return false;
    }

    @Override
    public int InsertFoodItem(FoodItem foodItem) {
        int id = 0;
        try {
            String query = "insert into ORDERMANAGEMENTDB.FOODITEMS  (FoodItemName,FoodItemCost,FoodItemImagePath) values(?,?,?);";
            pst = getConnection().prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
            pst.setString(1, foodItem.getFoodItemName());
            pst.setDouble(2, foodItem.getFoodItemCost());
            pst.setString(3, foodItem.getFoodImagePath());

            pst.execute();
            rs = pst.getGeneratedKeys();
            if (rs.next()) {
                id = rs.getInt(1);
                System.out.println("got Food Item id: " + id);
            }
            return id;

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Insert FoodItem failed" + ex.getMessage());
        }
        return id;
    }

    @Override
    public boolean UpdateFoodItem(FoodItem foodItem) {

        try {
            String query = "UPDATE ORDERMANAGEMENTDB.FOODITEMS  SET "
                    + "FoodItemName = ?,"
                    + "FoodItemCost = ?,"
                    + "FoodItemImagePath=?"
                    + " WHERE FoodItemID = ? ";
            pst = getConnection().prepareStatement(query);
            pst.setString(1, foodItem.getFoodItemName());
            pst.setDouble(2, foodItem.getFoodItemCost());
            pst.setString(3, foodItem.getFoodImagePath());
            pst.setInt(4, foodItem.getFoodItemId());
            pst.executeUpdate();
            return true;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Update Food Item failed");
        }
        return false;
    }

    @Override
    public boolean DeleteFoodItem(int foodItemID) {
        try {
            String query = "DELETE FROM ORDERMANAGEMENTDB.FOODITEMS  WHERE FoodItemID=" + foodItemID;
            st = getConnection().createStatement();
            st.executeUpdate(query);
            return true;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "No Such FoodItem exist");
        }
        return false;
    }

    @Override
    public int InsertOrder(FoodOrder foodOrder) {
        int id = 0;
        try {
            String query = "insert into ORDERMANAGEMENTDB.ORDER (CustomerID, OrderType, TableType,VenueType, OrderDate, OrderTime, FoodItems, NoOfGuests,VenueCost,FoodItemsCost, OrderCost, PaymentStatus) values(?,?,?,?,?,?,?,?,?,?,?,?)";
            pst = getConnection().prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
            pst.setInt(1, foodOrder.getFoodCustomerID());
            pst.setString(2, foodOrder.getFoodOrderType());
            pst.setString(3, foodOrder.getTableType());
            pst.setString(4, foodOrder.getVenueType());
            pst.setDate(5, foodOrder.getFoodOrderDate());
            pst.setString(6, foodOrder.getOrderTime());
            pst.setString(7, foodOrder.getFoodItems());
            pst.setInt(8, foodOrder.getGuestsCount());
            pst.setDouble(9, foodOrder.getVenueCost());
            pst.setDouble(10, foodOrder.getFoodItemsCost());
            pst.setDouble(11, foodOrder.getFoodOrderCost());
            pst.setString(12, foodOrder.getPaymentStatus());
            pst.execute();
            rs = pst.getGeneratedKeys();
            if (rs.next()) {
                id = rs.getInt(1);
                System.out.println("got Booking id" + id);
            }
            return id;

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Insert Order failed");
        }
        return id;

    }

    @Override
    public boolean UpdateOrder(FoodOrder foodOrder) {

        try {
            String query = "UPDATE ORDERMANAGEMENTDB.ORDER SET "
                    + "CustomerID= ?,"
                    + "OrderType= ?,"
                    + "TableType= ?,"
                    + "VenueType= ?,"
                    + "OrderDate= ?, "
                    + "FoodItems= ?,"
                    + "NoOfGuests= ?, "
                    + "VenueCost= ?, "
                    + "FoodItemsCost= ?, "
                    + "OrderCost= ?,"
                    + "PaymentStatus= ?"
                    + " WHERE bookingID = ? ";
            pst = getConnection().prepareStatement(query);
            pst.setInt(1, foodOrder.getFoodCustomerID());
            pst.setString(2, foodOrder.getFoodOrderType());
            pst.setString(3, foodOrder.getTableType());
            pst.setString(4, foodOrder.getVenueType());
            pst.setDate(5, foodOrder.getFoodOrderDate());
            pst.setString(6, foodOrder.getFoodItems());
            pst.setInt(7, foodOrder.getGuestsCount());
            pst.setDouble(8, foodOrder.getVenueCost());
            pst.setDouble(9, foodOrder.getFoodItemsCost());
            pst.setDouble(10, foodOrder.getFoodOrderCost());
            pst.setString(11, foodOrder.getPaymentStatus());
            pst.setInt(12, foodOrder.getBookingID());

            pst.executeUpdate();
            return true;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Update Order failed");
        }
        return false;
    }
    
     @Override
    public boolean UpdateOrderManager(Customer orderManager) {
        try {
            String query = "UPDATE ORDERMANAGEMENTDB.ORDERMANAGER SET "
                    + "Name= ?,"
                    + "Mobile= ?,"
                    + "Email= ?,"
                    + "Address= ?,"
                    + "Password= ?,"
                    + "Gender= ?, "
                    + "Subscribe= ?"
                    + " WHERE CustomerID = ? ";

            pst = getConnection().prepareStatement(query);
            pst.setString(1, orderManager.getName());
            pst.setString(2, orderManager.getMobile());
            pst.setString(3, orderManager.getEmail());
            pst.setString(4, orderManager.getAddress());
            pst.setString(5, orderManager.getPassword());
            pst.setString(6, orderManager.getGender());
            pst.setInt(7, orderManager.getSubscribe());
            pst.setInt(8, orderManager.getCustomerID());
            pst.executeUpdate();

            return true;
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Insert OrderManager failed");
        }
        return false;
    }

}
