-- MySQL dump 10.13  Distrib 8.0.13, for Win64 (x86_64)
--
-- Host: localhost    Database: ordermanagementdb
-- ------------------------------------------------------
-- Server version	8.0.13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `fooditems`
--

DROP TABLE IF EXISTS `fooditems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `fooditems` (
  `FoodItemID` int(11) NOT NULL AUTO_INCREMENT,
  `FoodItemName` varchar(500) NOT NULL,
  `FoodItemCost` double NOT NULL,
  `FoodItemImagePath` varchar(1000) NOT NULL,
  PRIMARY KEY (`FoodItemID`)
) ENGINE=InnoDB AUTO_INCREMENT=1014 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fooditems`
--

LOCK TABLES `fooditems` WRITE;
/*!40000 ALTER TABLE `fooditems` DISABLE KEYS */;
INSERT INTO `fooditems` VALUES (1002,'American Breakfast',30,'C:\\Users\\nithu\\Documents\\NetBeansProjects\\OnlineOrderManagementSystem_new\\src\\main\\java\\com\\order\\management\\onlineordermanagementsystem\\Icons\\FoodItems\\American_breakfast.jpg'),(1003,'American Buffet',80,'C:\\Users\\nithu\\Documents\\NetBeansProjects\\OnlineOrderManagementSystem_new\\src\\main\\java\\com\\order\\management\\onlineordermanagementsystem\\Icons\\FoodItems\\American_lunchbuffet.JPG'),(1004,'American nonveg Breakfast',35,'C:\\Users\\nithu\\Documents\\NetBeansProjects\\OnlineOrderManagementSystem_new\\src\\main\\java\\com\\order\\management\\onlineordermanagementsystem\\Icons\\FoodItems\\American_nonveg_breakfast.jpg'),(1005,'AMerican nonveg Buffet',70,'C:\\Users\\nithu\\Documents\\NetBeansProjects\\OnlineOrderManagementSystem_new\\src\\main\\java\\com\\order\\management\\onlineordermanagementsystem\\Icons\\FoodItems\\American_nonvegLbuffet.jpg'),(1006,'AMerican Veg Breakfast',25,'C:\\Users\\nithu\\Documents\\NetBeansProjects\\OnlineOrderManagementSystem_new\\src\\main\\java\\com\\order\\management\\onlineordermanagementsystem\\Icons\\FoodItems\\American_Veg_Breakfast.jpg'),(1007,'American Veg Buffet',50,'C:\\Users\\nithu\\Documents\\NetBeansProjects\\OnlineOrderManagementSystem_new\\src\\main\\java\\com\\order\\management\\onlineordermanagementsystem\\Icons\\FoodItems\\American_veg_buffet.jpg'),(1008,'Italian Breakfast',35,'C:\\Users\\nithu\\Documents\\NetBeansProjects\\OnlineOrderManagementSystem_new\\src\\main\\java\\com\\order\\management\\onlineordermanagementsystem\\Icons\\FoodItems\\Italian_breakfast.jpg'),(1009,'Italian Nonveg Buffet',65,'C:\\Users\\nithu\\Documents\\NetBeansProjects\\OnlineOrderManagementSystem_new\\src\\main\\java\\com\\order\\management\\onlineordermanagementsystem\\Icons\\FoodItems\\Italian_nonveg_buffet.jpg'),(1010,'Italian nonveg Breakfast',30,'C:\\Users\\nithu\\Documents\\NetBeansProjects\\OnlineOrderManagementSystem_new\\src\\main\\java\\com\\order\\management\\onlineordermanagementsystem\\Icons\\FoodItems\\Italian_nonvegbreakfast.jpg'),(1011,'Italian veg Breakfast',20,'C:\\Users\\nithu\\Documents\\NetBeansProjects\\OnlineOrderManagementSystem_new\\src\\main\\java\\com\\order\\management\\onlineordermanagementsystem\\Icons\\FoodItems\\Italian_vegbreakfast.jpg'),(1012,'Italian veg Buffet',40,'C:\\Users\\nithu\\Documents\\NetBeansProjects\\OnlineOrderManagementSystem_new\\src\\main\\java\\com\\order\\management\\onlineordermanagementsystem\\Icons\\FoodItems\\Italian_VegL.jpg'),(1013,'Italian Buffet',70,'C:\\Users\\nithu\\Documents\\NetBeansProjects\\OnlineOrderManagementSystem_new\\src\\main\\java\\com\\order\\management\\onlineordermanagementsystem\\Icons\\FoodItems\\Italian-buffet.jpg');
/*!40000 ALTER TABLE `fooditems` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-11-18 12:08:54
